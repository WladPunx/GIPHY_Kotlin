package by.wlad.koshelev.giphy.kotlin.Giphy.etc


import com.google.gson.annotations.SerializedName

data class Onclick(
    @SerializedName("url")
    var url: String
)