{
  "data": [
    {
      "type": "gif",
      "id": "mZyZQOAZRTi0dNONli",
      "url": "https://giphy.com/gifs/nbcthevoice-the-voice-season-21-mZyZQOAZRTi0dNONli",
      "slug": "nbcthevoice-the-voice-season-21-mZyZQOAZRTi0dNONli",
      "bitly_gif_url": "https://gph.is/g/Z7q81d0",
      "bitly_url": "https://gph.is/g/Z7q81d0",
      "embed_url": "https://giphy.com/embed/mZyZQOAZRTi0dNONli",
      "username": "nbcthevoice",
      "source": "",
      "title": "Ariana Grande Singing GIF by The Voice",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2021-07-27 17:32:42",
      "trending_datetime": "2021-08-12 02:05:08",
      "images": {
        "original": {
          "height": "281",
          "width": "500",
          "size": "1944737",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "394487",
          "mp4": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "650182",
          "webp": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "22",
          "hash": "d720b8e90d246091d24897d698476489"
        },
        "downsized": {
          "height": "281",
          "width": "500",
          "size": "1944737",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "281",
          "width": "500",
          "size": "1944737",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "281",
          "width": "500",
          "size": "1944737",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "172",
          "width": "307",
          "mp4_size": "78771",
          "mp4": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "281",
          "width": "500",
          "size": "1944737",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "356",
          "size": "709872",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "178086",
          "mp4": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "251340",
          "webp": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "356",
          "size": "209663",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "110902",
          "webp": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "178",
          "size": "207223",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "61937",
          "mp4": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "91978",
          "webp": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "178",
          "size": "11551",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "356",
          "size": "34791",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "112",
          "width": "200",
          "size": "272751",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "68407",
          "mp4": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "102890",
          "webp": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "112",
          "width": "200",
          "size": "75080",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "39920",
          "webp": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "56",
          "width": "100",
          "size": "76950",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "26702",
          "mp4": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "40916",
          "webp": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "56",
          "width": "100",
          "size": "4437",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "112",
          "width": "200",
          "size": "14692",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2537234",
          "mp4": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "281",
          "width": "500",
          "size": "94718",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "268",
          "width": "480",
          "mp4_size": "394487",
          "mp4": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "112",
          "width": "200",
          "mp4_size": "39927",
          "mp4": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "55",
          "width": "98",
          "size": "49780",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "80",
          "width": "142",
          "size": "29534",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "270",
          "width": "480",
          "size": "1944737",
          "url": "https://media4.giphy.com/media/mZyZQOAZRTi0dNONli/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media1.giphy.com/avatars/nbcthevoice/EFnfbU8nAqQv.jpg",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/nbcthevoice/",
        "username": "nbcthevoice",
        "display_name": "The Voice",
        "description": "",
        "instagram_url": "https://instagram.com/nbcthevoice",
        "website_url": "https://www.nbc.com/the-voice",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPW1aeVpRT0FaUlRpMGROT05saSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPW1aeVpRT0FaUlRpMGROT05saSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPW1aeVpRT0FaUlRpMGROT05saSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPW1aeVpRT0FaUlRpMGROT05saSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "RfzuN5VaomxrJZCQmw",
      "url": "https://giphy.com/gifs/LikeeUS-morning-good-my-love-RfzuN5VaomxrJZCQmw",
      "slug": "LikeeUS-morning-good-my-love-RfzuN5VaomxrJZCQmw",
      "bitly_gif_url": "https://gph.is/g/4M01gow",
      "bitly_url": "https://gph.is/g/4M01gow",
      "embed_url": "https://giphy.com/embed/RfzuN5VaomxrJZCQmw",
      "username": "LikeeUS",
      "source": "https://a.likee.tv/FvnB/ArtistGif",
      "title": "Good Night GIF by Likee US",
      "rating": "g",
      "content_url": "",
      "source_tld": "a.likee.tv",
      "source_post_url": "https://a.likee.tv/FvnB/ArtistGif",
      "is_sticker": 0,
      "import_datetime": "2021-07-02 07:37:07",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "309",
          "width": "206",
          "size": "117215",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "131476",
          "mp4": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "94118",
          "webp": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "5",
          "hash": "7a97c5c3b6d2279c12b14d04587a890d"
        },
        "downsized": {
          "height": "309",
          "width": "206",
          "size": "117215",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "309",
          "width": "206",
          "size": "117215",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "309",
          "width": "206",
          "size": "117215",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "308",
          "width": "206",
          "mp4_size": "40258",
          "mp4": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "309",
          "width": "206",
          "size": "117215",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "133",
          "size": "50439",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "18140",
          "mp4": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "50128",
          "webp": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "133",
          "size": "50439",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "52372",
          "webp": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "67",
          "size": "15846",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "7228",
          "mp4": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "16162",
          "webp": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "67",
          "size": "5114",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "133",
          "size": "16589",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "300",
          "width": "200",
          "size": "108622",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "31441",
          "mp4": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "88930",
          "webp": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "300",
          "width": "200",
          "size": "108622",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "94634",
          "webp": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "150",
          "width": "100",
          "size": "32268",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "11952",
          "mp4": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "32360",
          "webp": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "150",
          "width": "100",
          "size": "10040",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "300",
          "width": "200",
          "size": "28845",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1685294",
          "mp4": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "309",
          "width": "206",
          "size": "41203",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "720",
          "width": "480",
          "mp4_size": "131476",
          "mp4": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "308",
          "width": "206",
          "mp4_size": "40258",
          "mp4": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "162",
          "width": "108",
          "size": "47703",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "309",
          "width": "206",
          "size": "38494",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "720",
          "width": "480",
          "size": "117215",
          "url": "https://media2.giphy.com/media/RfzuN5VaomxrJZCQmw/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media3.giphy.com/avatars/LikeeUS/QvgMjjXqfXHV.png",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/LikeeUS/",
        "username": "LikeeUS",
        "display_name": "Likee US",
        "description": "Discover More Exquisite GIF Here! Get the APP Now!",
        "instagram_url": "https://instagram.com/likee_official_us",
        "website_url": "http://a.likee.tv/FvnB/ArtistGif",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPVJmenVONVZhb214ckpaQ1FtdyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVJmenVONVZhb214ckpaQ1FtdyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVJmenVONVZhb214ckpaQ1FtdyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVJmenVONVZhb214ckpaQ1FtdyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "26FfgvRKbtc6ea2zK",
      "url": "https://giphy.com/gifs/abcnetwork-dance-dancing-26FfgvRKbtc6ea2zK",
      "slug": "abcnetwork-dance-dancing-26FfgvRKbtc6ea2zK",
      "bitly_gif_url": "http://gph.is/2yKCVLh",
      "bitly_url": "http://gph.is/2yKCVLh",
      "embed_url": "https://giphy.com/embed/26FfgvRKbtc6ea2zK",
      "username": "abcnetwork",
      "source": "",
      "title": "Viola Davis Dancing GIF by ABC Network",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2017-10-25 23:48:05",
      "trending_datetime": "2021-08-11 22:00:13",
      "images": {
        "original": {
          "height": "270",
          "width": "480",
          "size": "3460177",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "518878",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "562048",
          "webp": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "71",
          "hash": "1a15e4592c14e0c094851a755c492350"
        },
        "downsized": {
          "height": "270",
          "width": "480",
          "size": "1747331",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "270",
          "width": "480",
          "size": "3460177",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "270",
          "width": "480",
          "size": "3460177",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "166",
          "width": "295",
          "mp4_size": "159179",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "270",
          "width": "480",
          "size": "38564",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "356",
          "size": "1489756",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "344362",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "412624",
          "webp": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "356",
          "size": "145118",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "76762",
          "webp": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "178",
          "size": "513011",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "140445",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "190682",
          "webp": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "178",
          "size": "9363",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "356",
          "size": "23088",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "113",
          "width": "200",
          "size": "652547",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "151139",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "210290",
          "webp": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "113",
          "width": "200",
          "size": "59329",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "30414",
          "webp": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "57",
          "width": "100",
          "size": "209498",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48572",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "96420",
          "webp": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "57",
          "width": "100",
          "size": "3834",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "113",
          "width": "200",
          "size": "11734",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1534923",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "270",
          "width": "480",
          "size": "52196",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "270",
          "width": "480",
          "mp4_size": "518878",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "182",
          "width": "323",
          "mp4_size": "42920",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "89",
          "width": "158",
          "size": "49553",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "162",
          "width": "288",
          "size": "41890",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "1080",
          "width": "1920",
          "mp4_size": "5948176",
          "mp4": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "270",
          "width": "480",
          "size": "3460177",
          "url": "https://media1.giphy.com/media/26FfgvRKbtc6ea2zK/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/abcnetwork/bl9kX1FQ1hgt.jpg",
        "banner_image": "https://media0.giphy.com/headers/abcnetwork/lCjo0pMOWQSt.jpg",
        "banner_url": "https://media0.giphy.com/headers/abcnetwork/lCjo0pMOWQSt.jpg",
        "profile_url": "https://giphy.com/abcnetwork/",
        "username": "abcnetwork",
        "display_name": "ABC Network",
        "description": "The official Giphy for the ABC Television Network.",
        "instagram_url": "https://instagram.com/@abcnetwork",
        "website_url": "",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPTI2RmZndlJLYnRjNmVhMnpLJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTI2RmZndlJLYnRjNmVhMnpLJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTI2RmZndlJLYnRjNmVhMnpLJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTI2RmZndlJLYnRjNmVhMnpLJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "Be9nOh8wsow8Kvt8Jx",
      "url": "https://giphy.com/gifs/happy-birthday-snoop-dogg-Be9nOh8wsow8Kvt8Jx",
      "slug": "happy-birthday-snoop-dogg-Be9nOh8wsow8Kvt8Jx",
      "bitly_gif_url": "https://gph.is/g/a9VnkdJ",
      "bitly_url": "https://gph.is/g/a9VnkdJ",
      "embed_url": "https://giphy.com/embed/Be9nOh8wsow8Kvt8Jx",
      "username": "",
      "source": "",
      "title": "Snoop Happy Birthday GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2021-06-02 22:31:19",
      "trending_datetime": "2021-06-12 14:49:03",
      "images": {
        "original": {
          "height": "360",
          "width": "480",
          "size": "2654187",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "568322",
          "mp4": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "715560",
          "webp": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "30",
          "hash": "fdbb9d85436a496624b3bcfea3f1e6e5"
        },
        "downsized": {
          "height": "360",
          "width": "480",
          "size": "1664470",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "360",
          "width": "480",
          "size": "2654187",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "360",
          "width": "480",
          "size": "2654187",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "212",
          "width": "282",
          "mp4_size": "142350",
          "mp4": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "360",
          "width": "480",
          "size": "58362",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "267",
          "size": "733612",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "205040",
          "mp4": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "319318",
          "webp": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "267",
          "size": "166725",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "96386",
          "webp": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "134",
          "size": "263002",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "86517",
          "mp4": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "144568",
          "webp": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "134",
          "size": "9288",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "267",
          "size": "25817",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "150",
          "width": "200",
          "size": "472636",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "143062",
          "mp4": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "232476",
          "webp": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "150",
          "width": "200",
          "size": "109794",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "63166",
          "webp": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "75",
          "width": "100",
          "size": "153832",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48552",
          "mp4": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "101540",
          "webp": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "75",
          "width": "100",
          "size": "5886",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "150",
          "width": "200",
          "size": "16207",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "4037736",
          "mp4": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "360",
          "width": "480",
          "size": "89249",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "360",
          "width": "480",
          "mp4_size": "568322",
          "mp4": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "112",
          "width": "149",
          "mp4_size": "46701",
          "mp4": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "64",
          "width": "85",
          "size": "49944",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "96",
          "width": "128",
          "size": "43324",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "360",
          "width": "480",
          "size": "2654187",
          "url": "https://media3.giphy.com/media/Be9nOh8wsow8Kvt8Jx/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPUJlOW5PaDh3c293OEt2dDhKeCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUJlOW5PaDh3c293OEt2dDhKeCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUJlOW5PaDh3c293OEt2dDhKeCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUJlOW5PaDh3c293OEt2dDhKeCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "ddnIutKdlz13HfgD0v",
      "url": "https://giphy.com/gifs/mlb-atlanta-braves-ddnIutKdlz13HfgD0v",
      "slug": "mlb-atlanta-braves-ddnIutKdlz13HfgD0v",
      "bitly_gif_url": "https://gph.is/2SIEjIp",
      "bitly_url": "https://gph.is/2SIEjIp",
      "embed_url": "https://giphy.com/embed/ddnIutKdlz13HfgD0v",
      "username": "mlb",
      "source": "braves.com",
      "title": "celebrate atlanta braves GIF by MLB",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "braves.com",
      "is_sticker": 0,
      "import_datetime": "2019-02-08 15:25:22",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "270",
          "width": "480",
          "size": "1485436",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "285088",
          "mp4": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "400668",
          "webp": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "49",
          "hash": "f74d5fa37e6abaa77f1029013c554f52"
        },
        "downsized": {
          "height": "270",
          "width": "480",
          "size": "1485436",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "270",
          "width": "480",
          "size": "1485436",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "270",
          "width": "480",
          "size": "1485436",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "226",
          "width": "401",
          "mp4_size": "84333",
          "mp4": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "270",
          "width": "480",
          "size": "1485436",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "356",
          "size": "819553",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "142636",
          "mp4": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "255268",
          "webp": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "356",
          "size": "99265",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "61404",
          "webp": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "178",
          "size": "269689",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "54044",
          "mp4": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "95644",
          "webp": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "178",
          "size": "4539",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "356",
          "size": "12075",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "113",
          "width": "200",
          "size": "329967",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "63418",
          "mp4": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "113630",
          "webp": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "113",
          "width": "200",
          "size": "40027",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "25284",
          "webp": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "57",
          "width": "100",
          "size": "109047",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "24189",
          "mp4": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "45116",
          "webp": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "57",
          "width": "100",
          "size": "2293",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "113",
          "width": "200",
          "size": "5296",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2156853",
          "mp4": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "270",
          "width": "480",
          "size": "22608",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "270",
          "width": "480",
          "mp4_size": "285088",
          "mp4": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "112",
          "width": "199",
          "mp4_size": "27654",
          "mp4": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "103",
          "width": "183",
          "size": "48008",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "138",
          "width": "246",
          "size": "48512",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "270",
          "width": "480",
          "size": "1485436",
          "url": "https://media2.giphy.com/media/ddnIutKdlz13HfgD0v/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media4.giphy.com/avatars/mlb/UTAk9uV8rZw2.jpg",
        "banner_image": "https://media4.giphy.com/channel_assets/mlb/8Y39J0Q4HSYL.gif",
        "banner_url": "https://media4.giphy.com/channel_assets/mlb/8Y39J0Q4HSYL.gif",
        "profile_url": "https://giphy.com/mlb/",
        "username": "mlb",
        "display_name": "MLB",
        "description": "Every GIF from every game of MLB! Find and share all of your favorite moments!",
        "instagram_url": "https://instagram.com/mlb",
        "website_url": "http://mlb.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPWRkbkl1dEtkbHoxM0hmZ0QwdiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWRkbkl1dEtkbHoxM0hmZ0QwdiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWRkbkl1dEtkbHoxM0hmZ0QwdiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWRkbkl1dEtkbHoxM0hmZ0QwdiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "UsHgX0Ze5NBxlTORSr",
      "url": "https://giphy.com/gifs/memecandy-UsHgX0Ze5NBxlTORSr",
      "slug": "memecandy-UsHgX0Ze5NBxlTORSr",
      "bitly_gif_url": "https://gph.is/g/aKNrnx9",
      "bitly_url": "https://gph.is/g/aKNrnx9",
      "embed_url": "https://giphy.com/embed/UsHgX0Ze5NBxlTORSr",
      "username": "memecandy",
      "source": "",
      "title": "I Love You Smile GIF by memecandy",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2019-12-11 23:44:08",
      "trending_datetime": "2021-05-17 05:15:11",
      "images": {
        "original": {
          "height": "498",
          "width": "279",
          "size": "1688535",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "1592199",
          "mp4": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "853588",
          "webp": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "36",
          "hash": "09cb3f784e579a29db6bf1d7decd2b1a"
        },
        "downsized": {
          "height": "498",
          "width": "279",
          "size": "1688535",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "498",
          "width": "279",
          "size": "1688535",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "498",
          "width": "279",
          "size": "1688535",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "266",
          "width": "148",
          "mp4_size": "22169",
          "mp4": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "498",
          "width": "279",
          "size": "1688535",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "112",
          "size": "314157",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "23422",
          "mp4": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "144168",
          "webp": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "112",
          "size": "64983",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "40408",
          "webp": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "56",
          "size": "94183",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "8747",
          "mp4": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "62264",
          "webp": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "56",
          "size": "4298",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "112",
          "size": "13773",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "357",
          "width": "200",
          "size": "969643",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "117191",
          "mp4": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "358152",
          "webp": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "357",
          "width": "200",
          "size": "180015",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "104616",
          "webp": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "179",
          "width": "100",
          "size": "304013",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "23003",
          "mp4": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "124062",
          "webp": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "179",
          "width": "100",
          "size": "10965",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "357",
          "width": "200",
          "size": "27624",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2533687",
          "mp4": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "498",
          "width": "279",
          "size": "48341",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "856",
          "width": "480",
          "mp4_size": "1592199",
          "mp4": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "198",
          "width": "110",
          "mp4_size": "13695",
          "mp4": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "107",
          "width": "60",
          "size": "47718",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "136",
          "width": "76",
          "size": "31820",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "857",
          "width": "480",
          "size": "1688535",
          "url": "https://media2.giphy.com/media/UsHgX0Ze5NBxlTORSr/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/default5.gif",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/memecandy/",
        "username": "memecandy",
        "display_name": "",
        "description": "",
        "instagram_url": "",
        "website_url": "",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPVVzSGdYMFplNU5CeGxUT1JTciZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVVzSGdYMFplNU5CeGxUT1JTciZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVVzSGdYMFplNU5CeGxUT1JTciZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVVzSGdYMFplNU5CeGxUT1JTciZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "cdNSp4L5vCU7aQrYnV",
      "url": "https://giphy.com/gifs/masonramsey-mason-ramsey-cdNSp4L5vCU7aQrYnV",
      "slug": "masonramsey-mason-ramsey-cdNSp4L5vCU7aQrYnV",
      "bitly_gif_url": "https://gph.is/2mvmOt5",
      "bitly_url": "https://gph.is/2mvmOt5",
      "embed_url": "https://giphy.com/embed/cdNSp4L5vCU7aQrYnV",
      "username": "masonramsey",
      "source": "",
      "title": "Lets Go Reaction GIF by Mason Ramsey",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2018-07-20 20:13:18",
      "trending_datetime": "2018-09-12 11:45:01",
      "images": {
        "original": {
          "height": "516",
          "width": "396",
          "size": "2057177",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "735678",
          "mp4": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "816114",
          "webp": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "24",
          "hash": "de63a9ca2cda3ec665268a4d85de984f"
        },
        "downsized": {
          "height": "516",
          "width": "396",
          "size": "1288280",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "516",
          "width": "396",
          "size": "2057177",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "516",
          "width": "396",
          "size": "2057177",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "284",
          "width": "217",
          "mp4_size": "100094",
          "mp4": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "516",
          "width": "396",
          "size": "57018",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "153",
          "size": "332293",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "98960",
          "mp4": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "236528",
          "webp": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "153",
          "size": "110087",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "61780",
          "webp": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "77",
          "size": "109384",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "32805",
          "mp4": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "74946",
          "webp": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "77",
          "size": "5563",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "153",
          "size": "15216",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "261",
          "width": "200",
          "size": "521202",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "151613",
          "mp4": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "370494",
          "webp": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "261",
          "width": "200",
          "size": "148209",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "97440",
          "webp": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "131",
          "width": "100",
          "size": "197042",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "45401",
          "mp4": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "116402",
          "webp": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "131",
          "width": "100",
          "size": "9351",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "261",
          "width": "200",
          "size": "23669",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3555280",
          "mp4": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "516",
          "width": "396",
          "size": "112450",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "624",
          "width": "480",
          "mp4_size": "735678",
          "mp4": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "164",
          "width": "125",
          "mp4_size": "40978",
          "mp4": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "104",
          "width": "80",
          "size": "45539",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "136",
          "width": "104",
          "size": "47266",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "625",
          "width": "480",
          "size": "2057177",
          "url": "https://media4.giphy.com/media/cdNSp4L5vCU7aQrYnV/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media2.giphy.com/avatars/masonramsey/Put6GlioRuvN.jpg",
        "banner_image": "https://media2.giphy.com/headers/masonramsey/ERdmCidULnva.jpg",
        "banner_url": "https://media2.giphy.com/headers/masonramsey/ERdmCidULnva.jpg",
        "profile_url": "https://giphy.com/masonramsey/",
        "username": "masonramsey",
        "display_name": "Mason Ramsey",
        "description": "Mason Ramsey, born in Illinois, has been playing guitar and singing since he was 3 years old. He recently took the internet by storm with his Walmart yodeling video, and now, he’s signed to Atlantic Records pursuing his dream of becoming a singer/songwriter. He's living proof that dreams do come true.",
        "instagram_url": "https://instagram.com/lilhankwilliams",
        "website_url": "http://masonramseyofficial.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPWNkTlNwNEw1dkNVN2FRclluViZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWNkTlNwNEw1dkNVN2FRclluViZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWNkTlNwNEw1dkNVN2FRclluViZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWNkTlNwNEw1dkNVN2FRclluViZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "xTiTnIOJjCGuVyQDHq",
      "url": "https://giphy.com/gifs/afv-fail-baby-win-xTiTnIOJjCGuVyQDHq",
      "slug": "afv-fail-baby-win-xTiTnIOJjCGuVyQDHq",
      "bitly_gif_url": "http://gph.is/1QPn5yj",
      "bitly_url": "http://gph.is/1QPn5yj",
      "embed_url": "https://giphy.com/embed/xTiTnIOJjCGuVyQDHq",
      "username": "afv",
      "source": "",
      "title": "baby lol GIF by America's Funniest Home Videos",
      "rating": "pg",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2015-10-20 17:52:18",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "230",
          "width": "340",
          "size": "2083146",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "1412333",
          "mp4": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "958058",
          "webp": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "42",
          "hash": "3a629585ea30d76dcb67ed570834a3c3"
        },
        "downsized": {
          "height": "230",
          "width": "340",
          "size": "1295777",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "230",
          "width": "340",
          "size": "2083146",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "230",
          "width": "340",
          "size": "2083146",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "104",
          "width": "153",
          "mp4_size": "69294",
          "mp4": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "230",
          "width": "340",
          "size": "36541",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "296",
          "size": "1326758",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "433582",
          "mp4": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "782770",
          "webp": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "296",
          "size": "204629",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "115716",
          "webp": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "148",
          "size": "449581",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "119717",
          "mp4": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "235028",
          "webp": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "148",
          "size": "12050",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "296",
          "size": "35396",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "135",
          "width": "200",
          "size": "626983",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "205322",
          "mp4": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "399636",
          "webp": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "135",
          "width": "200",
          "size": "102480",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "59336",
          "webp": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "68",
          "width": "100",
          "size": "188058",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48224",
          "mp4": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "119558",
          "webp": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "68",
          "width": "100",
          "size": "5666",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "135",
          "width": "200",
          "size": "17188",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3720318",
          "mp4": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "230",
          "width": "340",
          "size": "55380",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "324",
          "width": "480",
          "mp4_size": "1412333",
          "mp4": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "122",
          "width": "180",
          "mp4_size": "41387",
          "mp4": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "76",
          "width": "112",
          "size": "48919",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "74",
          "width": "110",
          "size": "34236",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "325",
          "width": "480",
          "size": "2083146",
          "url": "https://media2.giphy.com/media/xTiTnIOJjCGuVyQDHq/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media1.giphy.com/avatars/afv/duCgJiq67muO.jpg",
        "banner_image": "https://media1.giphy.com/headers/afv/TAOb1kS1fcLv.gif",
        "banner_url": "https://media1.giphy.com/headers/afv/TAOb1kS1fcLv.gif",
        "profile_url": "https://giphy.com/afv/",
        "username": "afv",
        "display_name": "America's Funniest Home Videos",
        "description": "AFV:  Over 1 million videos aching to be gifs. Watch, every Sun night at 7 on ABC.",
        "instagram_url": "https://instagram.com/afvofficial",
        "website_url": "https://www.afv.com/",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPXhUaVRuSU9KakNHdVZ5UURIcSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXhUaVRuSU9KakNHdVZ5UURIcSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXhUaVRuSU9KakNHdVZ5UURIcSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXhUaVRuSU9KakNHdVZ5UURIcSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "gj0QdZ9FgqGhOBNlFS",
      "url": "https://giphy.com/gifs/lol-laugh-laughing-gj0QdZ9FgqGhOBNlFS",
      "slug": "lol-laugh-laughing-gj0QdZ9FgqGhOBNlFS",
      "bitly_gif_url": "https://gph.is/g/aXy5xPZ",
      "bitly_url": "https://gph.is/g/aXy5xPZ",
      "embed_url": "https://giphy.com/embed/gj0QdZ9FgqGhOBNlFS",
      "username": "",
      "source": "https://vimeo.com/217746543",
      "title": "Baby Reaction GIF by MOODMAN",
      "rating": "g",
      "content_url": "",
      "source_tld": "vimeo.com",
      "source_post_url": "https://vimeo.com/217746543",
      "is_sticker": 0,
      "import_datetime": "2019-05-02 22:33:17",
      "trending_datetime": "2020-02-21 19:15:10",
      "images": {
        "original": {
          "height": "498",
          "width": "392",
          "size": "4374002",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "2139375",
          "mp4": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "1923784",
          "webp": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "85",
          "hash": "6c98885f9f632627b9f055d75a3ff8fc"
        },
        "downsized": {
          "height": "398",
          "width": "313",
          "size": "1795698",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "498",
          "width": "392",
          "size": "4374002",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "498",
          "width": "392",
          "size": "4374002",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "198",
          "width": "155",
          "mp4_size": "80800",
          "mp4": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "398",
          "width": "313",
          "size": "35133",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "157",
          "size": "980595",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "157992",
          "mp4": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "277470",
          "webp": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "157",
          "size": "70807",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "43944",
          "webp": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "79",
          "size": "307254",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "56657",
          "mp4": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "119794",
          "webp": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "79",
          "size": "4537",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "157",
          "size": "15339",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "254",
          "width": "200",
          "size": "1254721",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "239212",
          "mp4": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "389652",
          "webp": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "254",
          "width": "200",
          "size": "122125",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "64500",
          "webp": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "127",
          "width": "100",
          "size": "440806",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48018",
          "mp4": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "159900",
          "webp": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "127",
          "width": "100",
          "size": "6051",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "254",
          "width": "200",
          "size": "15770",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3109597",
          "mp4": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "498",
          "width": "392",
          "size": "68276",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "608",
          "width": "480",
          "mp4_size": "2139375",
          "mp4": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "218",
          "width": "171",
          "mp4_size": "39081",
          "mp4": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "82",
          "width": "65",
          "size": "48274",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "144",
          "width": "114",
          "size": "30310",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "610",
          "width": "480",
          "size": "4374002",
          "url": "https://media0.giphy.com/media/gj0QdZ9FgqGhOBNlFS/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPWdqMFFkWjlGZ3FHaE9CTmxGUyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWdqMFFkWjlGZ3FHaE9CTmxGUyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWdqMFFkWjlGZ3FHaE9CTmxGUyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWdqMFFkWjlGZ3FHaE9CTmxGUyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "RIebm3hi5X395PPsd7",
      "url": "https://giphy.com/gifs/memecandy-RIebm3hi5X395PPsd7",
      "slug": "memecandy-RIebm3hi5X395PPsd7",
      "bitly_gif_url": "https://gph.is/g/amnKA6X",
      "bitly_url": "https://gph.is/g/amnKA6X",
      "embed_url": "https://giphy.com/embed/RIebm3hi5X395PPsd7",
      "username": "memecandy",
      "source": "",
      "title": "Sweet Dreams GIF by memecandy",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2019-12-11 23:46:02",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "498",
          "width": "398",
          "size": "6222635",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "2067098",
          "mp4": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "2298650",
          "webp": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "60",
          "hash": "a51a2212f30b6deb2d0034143a3338a3"
        },
        "downsized": {
          "height": "283",
          "width": "226",
          "size": "1341552",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "498",
          "width": "398",
          "size": "6222635",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "498",
          "width": "398",
          "size": "4088083",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy-downsized-medium.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-medium.gif&ct=g"
        },
        "downsized_small": {
          "height": "198",
          "width": "158",
          "mp4_size": "81343",
          "mp4": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "283",
          "width": "226",
          "size": "23369",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "160",
          "size": "890935",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "156644",
          "mp4": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "471196",
          "webp": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "160",
          "size": "99405",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "59910",
          "webp": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "80",
          "size": "283208",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "57030",
          "mp4": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "175314",
          "webp": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "80",
          "size": "5576",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "160",
          "size": "15809",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "250",
          "width": "200",
          "size": "1272888",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "224117",
          "mp4": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "642664",
          "webp": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "250",
          "width": "200",
          "size": "147069",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "87794",
          "webp": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "125",
          "width": "100",
          "size": "416510",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48455",
          "mp4": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "242250",
          "webp": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "125",
          "width": "100",
          "size": "8075",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "250",
          "width": "200",
          "size": "22258",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2922536",
          "mp4": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "498",
          "width": "398",
          "size": "105852",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "600",
          "width": "480",
          "mp4_size": "2067098",
          "mp4": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "228",
          "width": "182",
          "mp4_size": "36568",
          "mp4": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "85",
          "width": "68",
          "size": "49937",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "122",
          "width": "98",
          "size": "37332",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "601",
          "width": "480",
          "size": "6222635",
          "url": "https://media0.giphy.com/media/RIebm3hi5X395PPsd7/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media4.giphy.com/avatars/default5.gif",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/memecandy/",
        "username": "memecandy",
        "display_name": "",
        "description": "",
        "instagram_url": "",
        "website_url": "",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPVJJZWJtM2hpNVgzOTVQUHNkNyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVJJZWJtM2hpNVgzOTVQUHNkNyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVJJZWJtM2hpNVgzOTVQUHNkNyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVJJZWJtM2hpNVgzOTVQUHNkNyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "kZD8cN1MycfKw",
      "url": "https://giphy.com/gifs/why-rachel-dolezal-chick-kZD8cN1MycfKw",
      "slug": "why-rachel-dolezal-chick-kZD8cN1MycfKw",
      "bitly_gif_url": "http://gph.is/1g1YsCq",
      "bitly_url": "http://gph.is/1g1YsCq",
      "embed_url": "https://giphy.com/embed/kZD8cN1MycfKw",
      "username": "",
      "source": "http://www.lipstickalley.com/showthread.php/917603-India-Love-Says-She-s-Never-Getting-Back-With-The-Game",
      "title": "Unimpressed Viola Davis GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.lipstickalley.com",
      "source_post_url": "http://www.lipstickalley.com/showthread.php/917603-India-Love-Says-She-s-Never-Getting-Back-With-The-Game",
      "is_sticker": 0,
      "import_datetime": "2015-07-21 16:20:27",
      "trending_datetime": "2021-08-11 21:45:26",
      "images": {
        "original": {
          "height": "245",
          "width": "245",
          "size": "1849069",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "2153384",
          "mp4": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "750660",
          "webp": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "62",
          "hash": "189f519b65333eb2ad4989bc9261b6df"
        },
        "downsized": {
          "height": "245",
          "width": "245",
          "size": "1849069",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "245",
          "width": "245",
          "size": "1849069",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "245",
          "width": "245",
          "size": "1849069",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "152",
          "width": "152",
          "mp4_size": "70439",
          "mp4": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "245",
          "width": "245",
          "size": "1849069",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "1067015",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "251958",
          "mp4": "https://media0.giphy.com/media/kZD8cN1MycfKw/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "395926",
          "webp": "https://media0.giphy.com/media/kZD8cN1MycfKw/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "111621",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "54686",
          "webp": "https://media0.giphy.com/media/kZD8cN1MycfKw/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "306153",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "64874",
          "mp4": "https://media0.giphy.com/media/kZD8cN1MycfKw/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "128494",
          "webp": "https://media0.giphy.com/media/kZD8cN1MycfKw/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "5991",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "19626",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "1067015",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "251958",
          "mp4": "https://media0.giphy.com/media/kZD8cN1MycfKw/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "395926",
          "webp": "https://media0.giphy.com/media/kZD8cN1MycfKw/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "111621",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "54686",
          "webp": "https://media0.giphy.com/media/kZD8cN1MycfKw/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "306153",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48507",
          "mp4": "https://media0.giphy.com/media/kZD8cN1MycfKw/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "128494",
          "webp": "https://media0.giphy.com/media/kZD8cN1MycfKw/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "5991",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "19626",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "6375322",
          "mp4": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "245",
          "width": "245",
          "size": "39493",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "2153384",
          "mp4": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "168",
          "width": "168",
          "mp4_size": "41721",
          "mp4": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "78",
          "width": "78",
          "size": "47443",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "108",
          "width": "108",
          "size": "27260",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "1849069",
          "url": "https://media0.giphy.com/media/kZD8cN1MycfKw/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPWtaRDhjTjFNeWNmS3cmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWtaRDhjTjFNeWNmS3cmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWtaRDhjTjFNeWNmS3cmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWtaRDhjTjFNeWNmS3cmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "bpYXSdwzUhAkbrtUDd",
      "url": "https://giphy.com/gifs/thelonelyisland-lonely-island-i-think-you-should-leave-itysl-bpYXSdwzUhAkbrtUDd",
      "slug": "thelonelyisland-lonely-island-i-think-you-should-leave-itysl-bpYXSdwzUhAkbrtUDd",
      "bitly_gif_url": "https://gph.is/g/aRYorMd",
      "bitly_url": "https://gph.is/g/aRYorMd",
      "embed_url": "https://giphy.com/embed/bpYXSdwzUhAkbrtUDd",
      "username": "thelonelyisland",
      "source": "http://www.thelonelyisland.com/",
      "title": "Excited Season 2 GIF by The Lonely Island",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.thelonelyisland.com",
      "source_post_url": "http://www.thelonelyisland.com/",
      "is_sticker": 0,
      "import_datetime": "2021-06-28 16:37:33",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "360",
          "width": "480",
          "size": "805519",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "104030",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "147970",
          "webp": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "16",
          "hash": "7dfb3e03875fb674adadea23084c2325"
        },
        "downsized": {
          "height": "360",
          "width": "480",
          "size": "805519",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "360",
          "width": "480",
          "size": "805519",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "360",
          "width": "480",
          "size": "805519",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "360",
          "width": "480",
          "mp4_size": "104030",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "360",
          "width": "480",
          "size": "805519",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "267",
          "size": "228403",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "44798",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "78342",
          "webp": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "267",
          "size": "96836",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "50464",
          "webp": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "134",
          "size": "79900",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "19663",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "34010",
          "webp": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "134",
          "size": "5468",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "267",
          "size": "14441",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "150",
          "width": "200",
          "size": "176083",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "31696",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "56068",
          "webp": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "150",
          "width": "200",
          "size": "65323",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "33396",
          "webp": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "75",
          "width": "100",
          "size": "53520",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "13423",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "24066",
          "webp": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "75",
          "width": "100",
          "size": "3929",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "150",
          "width": "200",
          "size": "13597",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1365771",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "360",
          "width": "480",
          "size": "48316",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "360",
          "width": "480",
          "mp4_size": "104030",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "248",
          "width": "330",
          "mp4_size": "30484",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "63",
          "width": "84",
          "size": "47920",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "188",
          "width": "250",
          "size": "44430",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "900",
          "width": "1200",
          "mp4_size": "564435",
          "mp4": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "360",
          "width": "480",
          "size": "805519",
          "url": "https://media1.giphy.com/media/bpYXSdwzUhAkbrtUDd/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media2.giphy.com/avatars/thelonelyisland/xeKg7YHsR1mV.gif",
        "banner_image": "https://media2.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "banner_url": "https://media2.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "profile_url": "https://giphy.com/thelonelyisland/",
        "username": "thelonelyisland",
        "display_name": "The Lonely Island",
        "description": "",
        "instagram_url": "https://instagram.com/thelonelyisland",
        "website_url": "http://www.thelonelyisland.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPWJwWVhTZHd6VWhBa2JydFVEZCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWJwWVhTZHd6VWhBa2JydFVEZCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWJwWVhTZHd6VWhBa2JydFVEZCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWJwWVhTZHd6VWhBa2JydFVEZCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "q73L1yOsN9PMO6a0Eo",
      "url": "https://giphy.com/gifs/fallontonight-jimmy-fallon-tonight-show-marlon-q73L1yOsN9PMO6a0Eo",
      "slug": "fallontonight-jimmy-fallon-tonight-show-marlon-q73L1yOsN9PMO6a0Eo",
      "bitly_gif_url": "https://gph.is/g/aQbQ7kq",
      "bitly_url": "https://gph.is/g/aQbQ7kq",
      "embed_url": "https://giphy.com/embed/q73L1yOsN9PMO6a0Eo",
      "username": "fallontonight",
      "source": "",
      "title": "I Love You Ily GIF by The Tonight Show Starring Jimmy Fallon",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2021-08-11 16:29:11",
      "trending_datetime": "2021-08-11 21:27:00",
      "images": {
        "original": {
          "height": "343",
          "width": "480",
          "size": "958465",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "200965",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "304694",
          "webp": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "15",
          "hash": "fea0991fb16fd6c76bb601fc8d8fe12c"
        },
        "downsized": {
          "height": "343",
          "width": "480",
          "size": "958465",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "343",
          "width": "480",
          "size": "958465",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "343",
          "width": "480",
          "size": "958465",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "306",
          "width": "429",
          "mp4_size": "94173",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "343",
          "width": "480",
          "size": "958465",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "280",
          "size": "296787",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "88313",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "154956",
          "webp": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "280",
          "size": "139039",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "81556",
          "webp": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "140",
          "size": "99993",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "33778",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "63490",
          "webp": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "140",
          "size": "8457",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "280",
          "size": "21787",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "143",
          "width": "200",
          "size": "180765",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "53992",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "100190",
          "webp": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "143",
          "width": "200",
          "size": "73768",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "49534",
          "webp": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "72",
          "width": "100",
          "size": "58282",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "21655",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "40682",
          "webp": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "72",
          "width": "100",
          "size": "4909",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "143",
          "width": "200",
          "size": "17074",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1632801",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "343",
          "width": "480",
          "size": "107418",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "342",
          "width": "480",
          "mp4_size": "200965",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "152",
          "width": "213",
          "mp4_size": "36602",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "73",
          "width": "102",
          "size": "48762",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "146",
          "width": "204",
          "size": "49428",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "950",
          "width": "1330",
          "mp4_size": "3019166",
          "mp4": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "343",
          "width": "480",
          "size": "958465",
          "url": "https://media3.giphy.com/media/q73L1yOsN9PMO6a0Eo/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/fallontonight/x4sLtQUiIWcD.jpg",
        "banner_image": "https://media0.giphy.com/headers/larrysprings/xWSnnvlxX1Cu.gif",
        "banner_url": "https://media0.giphy.com/headers/larrysprings/xWSnnvlxX1Cu.gif",
        "profile_url": "https://giphy.com/fallontonight/",
        "username": "fallontonight",
        "display_name": "The Tonight Show Starring Jimmy Fallon",
        "description": "Here's the about section",
        "instagram_url": "https://instagram.com/fallontonight",
        "website_url": "",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPXE3M0wxeU9zTjlQTU82YTBFbyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXE3M0wxeU9zTjlQTU82YTBFbyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXE3M0wxeU9zTjlQTU82YTBFbyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXE3M0wxeU9zTjlQTU82YTBFbyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "e5I0YiwNYkG5y",
      "url": "https://giphy.com/gifs/good-night-e5I0YiwNYkG5y",
      "slug": "good-night-e5I0YiwNYkG5y",
      "bitly_gif_url": "http://gph.is/2cO2m23",
      "bitly_url": "http://gph.is/2cO2m23",
      "embed_url": "https://giphy.com/embed/e5I0YiwNYkG5y",
      "username": "",
      "source": "https://123greetingsquotes.com/free-good-night-images-awesome-to-send",
      "title": "good night GIF by youramazing",
      "rating": "g",
      "content_url": "",
      "source_tld": "123greetingsquotes.com",
      "source_post_url": "https://123greetingsquotes.com/free-good-night-images-awesome-to-send",
      "is_sticker": 0,
      "import_datetime": "2016-09-24 00:40:34",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "480",
          "width": "320",
          "size": "854658",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "699896",
          "mp4": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "451714",
          "webp": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "18",
          "hash": "22f93b8e9bf428742f7472a5c7dfc98a"
        },
        "downsized": {
          "height": "480",
          "width": "320",
          "size": "854658",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "480",
          "width": "320",
          "size": "854658",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "480",
          "width": "320",
          "size": "854658",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "336",
          "width": "224",
          "mp4_size": "104016",
          "mp4": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "480",
          "width": "320",
          "size": "854658",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "133",
          "size": "173356",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "67686",
          "mp4": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "99698",
          "webp": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "133",
          "size": "58240",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "34522",
          "webp": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "67",
          "size": "50895",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "20371",
          "mp4": "https://media2.giphy.com/media/e5I0YiwNYkG5y/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "33456",
          "webp": "https://media2.giphy.com/media/e5I0YiwNYkG5y/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "67",
          "size": "3756",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "133",
          "size": "11185",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "300",
          "width": "200",
          "size": "358439",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "138083",
          "mp4": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "188730",
          "webp": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "300",
          "width": "200",
          "size": "123118",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "68688",
          "webp": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "150",
          "width": "100",
          "size": "102642",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "39624",
          "mp4": "https://media2.giphy.com/media/e5I0YiwNYkG5y/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "63114",
          "webp": "https://media2.giphy.com/media/e5I0YiwNYkG5y/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "150",
          "width": "100",
          "size": "6725",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "300",
          "width": "200",
          "size": "20878",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3224781",
          "mp4": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "320",
          "size": "53335",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "720",
          "width": "480",
          "mp4_size": "699896",
          "mp4": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "192",
          "width": "128",
          "mp4_size": "39532",
          "mp4": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "118",
          "width": "79",
          "size": "49549",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "152",
          "width": "102",
          "size": "36786",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "720",
          "width": "480",
          "size": "854658",
          "url": "https://media2.giphy.com/media/e5I0YiwNYkG5y/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPWU1STBZaXdOWWtHNXkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWU1STBZaXdOWWtHNXkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWU1STBZaXdOWWtHNXkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWU1STBZaXdOWWtHNXkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "LGBKlgMCKQbkDKcG4t",
      "url": "https://giphy.com/gifs/happy-birthday-wishes-heart-LGBKlgMCKQbkDKcG4t",
      "slug": "happy-birthday-wishes-heart-LGBKlgMCKQbkDKcG4t",
      "bitly_gif_url": "https://gph.is/g/ZPqAO1r",
      "bitly_url": "https://gph.is/g/ZPqAO1r",
      "embed_url": "https://giphy.com/embed/LGBKlgMCKQbkDKcG4t",
      "username": "dotdave",
      "source": "https://www.3danimatedgifs.com/",
      "title": "Happy Birthday GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.3danimatedgifs.com",
      "source_post_url": "https://www.3danimatedgifs.com/",
      "is_sticker": 0,
      "import_datetime": "2020-12-12 13:49:22",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "400",
          "width": "400",
          "size": "2121423",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "1663710",
          "mp4": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "1105902",
          "webp": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "40",
          "hash": "ad4a581fabcc1403c99511735aa47d2b"
        },
        "downsized": {
          "height": "320",
          "width": "320",
          "size": "1550048",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "400",
          "width": "400",
          "size": "2121423",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "400",
          "width": "400",
          "size": "2121423",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "160",
          "width": "160",
          "mp4_size": "160392",
          "mp4": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "320",
          "width": "320",
          "size": "36588",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "750237",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "371449",
          "mp4": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "348090",
          "webp": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "144797",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "100044",
          "webp": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "239123",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "107826",
          "mp4": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "106468",
          "webp": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "6640",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "18455",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "750237",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "371449",
          "mp4": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "348090",
          "webp": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "144797",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "100044",
          "webp": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "239123",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48831",
          "mp4": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "106468",
          "webp": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "6640",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "18455",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "12480632",
          "mp4": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "400",
          "width": "400",
          "size": "51850",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "1663710",
          "mp4": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "150",
          "width": "150",
          "mp4_size": "49498",
          "mp4": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "69",
          "width": "69",
          "size": "47356",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "82",
          "width": "82",
          "size": "34030",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "2121423",
          "url": "https://media3.giphy.com/media/LGBKlgMCKQbkDKcG4t/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/dotdave/UWEU18gEPNwb.gif",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/channel/dotdave/",
        "username": "dotdave",
        "display_name": "3D Gif Artist",
        "description": "I'm just a retired old boy who uses ancient CAD software to create these distinctive but weird gifs.",
        "instagram_url": "",
        "website_url": "https://www.3danimatedgifs.com/",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPUxHQktsZ01DS1Fia0RLY0c0dCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUxHQktsZ01DS1Fia0RLY0c0dCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUxHQktsZ01DS1Fia0RLY0c0dCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUxHQktsZ01DS1Fia0RLY0c0dCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "28KZhuflOUQIH5Bqgk",
      "url": "https://giphy.com/gifs/mlb-baseball-all-star-2018-28KZhuflOUQIH5Bqgk",
      "slug": "mlb-baseball-all-star-2018-28KZhuflOUQIH5Bqgk",
      "bitly_gif_url": "https://gph.is/2OyTLSg",
      "bitly_url": "https://gph.is/2OyTLSg",
      "embed_url": "https://giphy.com/embed/28KZhuflOUQIH5Bqgk",
      "username": "mlb",
      "source": "mlb.com",
      "title": "atlanta braves thumbs down GIF by MLB",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "mlb.com",
      "is_sticker": 0,
      "import_datetime": "2018-08-01 17:03:55",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "270",
          "width": "480",
          "size": "1191574",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "84473",
          "mp4": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "408040",
          "webp": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "37",
          "hash": "d15ec3baee89624e36f13e3a7aa10ccf"
        },
        "downsized": {
          "height": "270",
          "width": "480",
          "size": "1191574",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "270",
          "width": "480",
          "size": "1191574",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "270",
          "width": "480",
          "size": "1191574",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "270",
          "width": "480",
          "mp4_size": "113453",
          "mp4": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "270",
          "width": "480",
          "size": "1191574",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "356",
          "size": "657717",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "56247",
          "mp4": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "246456",
          "webp": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "356",
          "size": "118439",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "39958",
          "webp": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "178",
          "size": "176799",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "23799",
          "mp4": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "96948",
          "webp": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "178",
          "size": "6343",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "356",
          "size": "19780",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "113",
          "width": "200",
          "size": "216055",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "26836",
          "mp4": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "114376",
          "webp": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "113",
          "width": "200",
          "size": "42178",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "18614",
          "webp": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "57",
          "width": "100",
          "size": "56981",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "10754",
          "mp4": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "43378",
          "webp": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "57",
          "width": "100",
          "size": "2790",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "113",
          "width": "200",
          "size": "7568",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1533429",
          "mp4": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "270",
          "width": "480",
          "size": "33822",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "270",
          "width": "480",
          "mp4_size": "84473",
          "mp4": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "178",
          "width": "318",
          "mp4_size": "24143",
          "mp4": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "102",
          "width": "181",
          "size": "48310",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "149",
          "width": "265",
          "size": "49066",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "270",
          "width": "480",
          "size": "1191574",
          "url": "https://media0.giphy.com/media/28KZhuflOUQIH5Bqgk/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media3.giphy.com/avatars/mlb/UTAk9uV8rZw2.jpg",
        "banner_image": "https://media3.giphy.com/channel_assets/mlb/8Y39J0Q4HSYL.gif",
        "banner_url": "https://media3.giphy.com/channel_assets/mlb/8Y39J0Q4HSYL.gif",
        "profile_url": "https://giphy.com/mlb/",
        "username": "mlb",
        "display_name": "MLB",
        "description": "Every GIF from every game of MLB! Find and share all of your favorite moments!",
        "instagram_url": "https://instagram.com/mlb",
        "website_url": "http://mlb.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPTI4S1podWZsT1VRSUg1QnFnayZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTI4S1podWZsT1VRSUg1QnFnayZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTI4S1podWZsT1VRSUg1QnFnayZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTI4S1podWZsT1VRSUg1QnFnayZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "TCKxvBY0MA3uKzXdeo",
      "url": "https://giphy.com/gifs/Canticosworld-besitos-besito-canticos-TCKxvBY0MA3uKzXdeo",
      "slug": "Canticosworld-besitos-besito-canticos-TCKxvBY0MA3uKzXdeo",
      "bitly_gif_url": "https://gph.is/g/aQd6W7x",
      "bitly_url": "https://gph.is/g/aQd6W7x",
      "embed_url": "https://giphy.com/embed/TCKxvBY0MA3uKzXdeo",
      "username": "Canticosworld",
      "source": "canticosworld.com",
      "title": "I Love You Hearts GIF by Canticos World",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "canticosworld.com",
      "is_sticker": 0,
      "import_datetime": "2021-02-03 20:14:18",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "480",
          "width": "480",
          "size": "737894",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "255177",
          "mp4": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "547310",
          "webp": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "59",
          "hash": "e6d28fb26535113e44096b3e271ffc65"
        },
        "downsized": {
          "height": "480",
          "width": "480",
          "size": "737894",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "480",
          "width": "480",
          "size": "737894",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "480",
          "width": "480",
          "size": "737894",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "428",
          "width": "428",
          "mp4_size": "134535",
          "mp4": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "480",
          "width": "480",
          "size": "737894",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "206519",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "98428",
          "mp4": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "190154",
          "webp": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "30617",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "27652",
          "webp": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "90326",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "38118",
          "mp4": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "77218",
          "webp": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "2824",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "5756",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "206519",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "98428",
          "mp4": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "190154",
          "webp": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "30617",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "27652",
          "webp": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "90326",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "38118",
          "mp4": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "77218",
          "webp": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "2824",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "5756",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "962396",
          "mp4": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "480",
          "size": "28906",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "255177",
          "mp4": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "348",
          "width": "348",
          "mp4_size": "34256",
          "mp4": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "121",
          "width": "121",
          "size": "49935",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "270",
          "width": "270",
          "size": "48964",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "737894",
          "url": "https://media0.giphy.com/media/TCKxvBY0MA3uKzXdeo/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/Canticosworld/XAQvnwakAYji.jpg",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/Canticosworld/",
        "username": "Canticosworld",
        "display_name": "Canticos World",
        "description": "",
        "instagram_url": "https://instagram.com/@canticosworld",
        "website_url": "http://canticosworld.com",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPVRDS3h2QlkwTUEzdUt6WGRlbyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRDS3h2QlkwTUEzdUt6WGRlbyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRDS3h2QlkwTUEzdUt6WGRlbyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRDS3h2QlkwTUEzdUt6WGRlbyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "NEvPzZ8bd1V4Y",
      "url": "https://giphy.com/gifs/editingandlayout-NEvPzZ8bd1V4Y",
      "slug": "editingandlayout-NEvPzZ8bd1V4Y",
      "bitly_gif_url": "http://gph.is/WArRsu",
      "bitly_url": "http://gph.is/WArRsu",
      "embed_url": "https://giphy.com/embed/NEvPzZ8bd1V4Y",
      "username": "editingandlayout",
      "source": "http://www.reddit.com/r/EditingAndLayout/comments/1inq4w/jeremiah_johnson_nod_alternate_version_cropped/",
      "title": "Proud Of You Reaction GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.reddit.com",
      "source_post_url": "http://www.reddit.com/r/EditingAndLayout/comments/1inq4w/jeremiah_johnson_nod_alternate_version_cropped/",
      "is_sticker": 0,
      "import_datetime": "2014-09-09 18:55:08",
      "trending_datetime": "2021-05-17 07:45:14",
      "images": {
        "original": {
          "height": "256",
          "width": "245",
          "size": "4754947",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "1892246",
          "mp4": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "1130770",
          "webp": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "113",
          "hash": "fa84d7051cab6e266d355469d5ef927e"
        },
        "downsized": {
          "height": "256",
          "width": "245",
          "size": "1301242",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "256",
          "width": "245",
          "size": "4754947",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "256",
          "width": "245",
          "size": "2884677",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy-downsized-medium.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-medium.gif&ct=g"
        },
        "downsized_small": {
          "height": "150",
          "width": "142",
          "mp4_size": "78111",
          "mp4": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "256",
          "width": "245",
          "size": "33146",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "191",
          "size": "2123498",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "251503",
          "mp4": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "681276",
          "webp": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "191",
          "size": "119300",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "65432",
          "webp": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "96",
          "size": "650894",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "93139",
          "mp4": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "241904",
          "webp": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "96",
          "size": "7487",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "191",
          "size": "21682",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "209",
          "width": "200",
          "size": "2301529",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "263744",
          "mp4": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "728330",
          "webp": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "209",
          "width": "200",
          "size": "131814",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "71968",
          "webp": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "105",
          "width": "100",
          "size": "703182",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "47648",
          "mp4": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "261116",
          "webp": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "105",
          "width": "100",
          "size": "8396",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "209",
          "width": "200",
          "size": "23428",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3013702",
          "mp4": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "256",
          "width": "245",
          "size": "51610",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "500",
          "width": "480",
          "mp4_size": "1892246",
          "mp4": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "204",
          "width": "194",
          "mp4_size": "34830",
          "mp4": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "66",
          "width": "63",
          "size": "48932",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "116",
          "width": "112",
          "size": "41574",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "502",
          "width": "480",
          "size": "4754947",
          "url": "https://media3.giphy.com/media/NEvPzZ8bd1V4Y/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/editingandlayout/brd0LGvcWNnx.gif",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/channel/editingandlayout/",
        "username": "editingandlayout",
        "display_name": "EditingAndLayout",
        "description": "gif king of reddit\r\n\r\ncreator of /r/HighQualityGifs\r\n\r\nlifelong fan of the Macho Man Randy Savage",
        "instagram_url": "https://instagram.com/EditingAndLayout",
        "website_url": "http://www.reddit.com/r/EditingAndLayout",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPU5FdlB6WjhiZDFWNFkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPU5FdlB6WjhiZDFWNFkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPU5FdlB6WjhiZDFWNFkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPU5FdlB6WjhiZDFWNFkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "l3fQf1OEAq0iri9RC",
      "url": "https://giphy.com/gifs/rodneydangerfield-lol-ok-sure-l3fQf1OEAq0iri9RC",
      "slug": "rodneydangerfield-lol-ok-sure-l3fQf1OEAq0iri9RC",
      "bitly_gif_url": "http://gph.is/2aWPM2x",
      "bitly_url": "http://gph.is/2aWPM2x",
      "embed_url": "https://giphy.com/embed/l3fQf1OEAq0iri9RC",
      "username": "rodneydangerfield",
      "source": "",
      "title": "K Lol GIF by Rodney Dangerfield",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2016-08-04 21:59:22",
      "trending_datetime": "2018-01-21 02:15:01",
      "images": {
        "original": {
          "height": "460",
          "width": "460",
          "size": "2515658",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "814117",
          "mp4": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "839138",
          "webp": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "87",
          "hash": "e778be5370f2b1b19863697fcbb638d2"
        },
        "downsized": {
          "height": "460",
          "width": "460",
          "size": "1577255",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "460",
          "width": "460",
          "size": "2515658",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "460",
          "width": "460",
          "size": "2515658",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "216",
          "width": "216",
          "mp4_size": "79296",
          "mp4": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "460",
          "width": "460",
          "size": "52884",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "625941",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "120302",
          "mp4": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "124364",
          "webp": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "97247",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "48544",
          "webp": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "210877",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "43961",
          "mp4": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "54268",
          "webp": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "5111",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "13884",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "625941",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "120302",
          "mp4": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "124364",
          "webp": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "97247",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "48544",
          "webp": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "210877",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "43961",
          "mp4": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "54268",
          "webp": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "5111",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "13884",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "5092599",
          "mp4": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "460",
          "width": "460",
          "size": "46413",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "814117",
          "mp4": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "150",
          "width": "150",
          "mp4_size": "43019",
          "mp4": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "69",
          "width": "69",
          "size": "49617",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "124",
          "width": "124",
          "size": "27378",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "2515658",
          "url": "https://media1.giphy.com/media/l3fQf1OEAq0iri9RC/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media2.giphy.com/avatars/rodneydangerfield/cbizUZsk296e.jpg",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/rodneydangerfield/",
        "username": "rodneydangerfield",
        "display_name": "Rodney Dangerfield",
        "description": "Official GIPHY account of the late great comedy legend Rodney Dangerfield, known for his iconic line “I don’t get no respect!”.",
        "instagram_url": "https://instagram.com/rodneynorespect",
        "website_url": "http://rodney.com/",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPWwzZlFmMU9FQXEwaXJpOVJDJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWwzZlFmMU9FQXEwaXJpOVJDJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWwzZlFmMU9FQXEwaXJpOVJDJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWwzZlFmMU9FQXEwaXJpOVJDJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "vfeKeZkbJpeUg",
      "url": "https://giphy.com/gifs/creepy-rhetthammersmith-halloween-mask-vfeKeZkbJpeUg",
      "slug": "creepy-rhetthammersmith-halloween-mask-vfeKeZkbJpeUg",
      "bitly_gif_url": "http://gph.is/1OQBObd",
      "bitly_url": "http://gph.is/1OQBObd",
      "embed_url": "https://giphy.com/embed/vfeKeZkbJpeUg",
      "username": "",
      "source": "http://rhetthammersmithhorror.tumblr.com/post/99514515663",
      "title": "sweet dreams horror GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "rhetthammersmithhorror.tumblr.com",
      "source_post_url": "http://rhetthammersmithhorror.tumblr.com/post/99514515663",
      "is_sticker": 0,
      "import_datetime": "2015-09-14 16:07:58",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "335",
          "width": "450",
          "size": "912987",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "217095",
          "mp4": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "244144",
          "webp": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "8",
          "hash": "7e6417788ae29cd895549fd9afbd36ba"
        },
        "downsized": {
          "height": "335",
          "width": "450",
          "size": "912987",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "335",
          "width": "450",
          "size": "912987",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "335",
          "width": "450",
          "size": "912987",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "298",
          "width": "401",
          "mp4_size": "57024",
          "mp4": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "335",
          "width": "450",
          "size": "912987",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "269",
          "size": "264458",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "54485",
          "mp4": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "82766",
          "webp": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "269",
          "size": "210799",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "106660",
          "webp": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "135",
          "size": "76755",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "19840",
          "mp4": "https://media3.giphy.com/media/vfeKeZkbJpeUg/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "29970",
          "webp": "https://media3.giphy.com/media/vfeKeZkbJpeUg/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "135",
          "size": "11083",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "269",
          "size": "32845",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "149",
          "width": "200",
          "size": "153497",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "35600",
          "mp4": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "53574",
          "webp": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "149",
          "width": "200",
          "size": "118167",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "64632",
          "webp": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "75",
          "width": "100",
          "size": "43397",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "12500",
          "mp4": "https://media3.giphy.com/media/vfeKeZkbJpeUg/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "18966",
          "webp": "https://media3.giphy.com/media/vfeKeZkbJpeUg/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "75",
          "width": "100",
          "size": "5961",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "149",
          "width": "200",
          "size": "19398",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "5956332",
          "mp4": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "335",
          "width": "450",
          "size": "114024",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "356",
          "width": "480",
          "mp4_size": "217095",
          "mp4": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "164",
          "width": "220",
          "mp4_size": "21462",
          "mp4": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "66",
          "width": "89",
          "size": "49868",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "144",
          "width": "194",
          "size": "33704",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "357",
          "width": "480",
          "size": "912987",
          "url": "https://media3.giphy.com/media/vfeKeZkbJpeUg/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPXZmZUtlWmtiSnBlVWcmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXZmZUtlWmtiSnBlVWcmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXZmZUtlWmtiSnBlVWcmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXZmZUtlWmtiSnBlVWcmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "LiUboYHPa1hf40XDRk",
      "url": "https://giphy.com/gifs/100Thieves-LiUboYHPa1hf40XDRk",
      "slug": "100Thieves-LiUboYHPa1hf40XDRk",
      "bitly_gif_url": "https://gph.is/g/Zk8M2lY",
      "bitly_url": "https://gph.is/g/Zk8M2lY",
      "embed_url": "https://giphy.com/embed/LiUboYHPa1hf40XDRk",
      "username": "100Thieves",
      "source": "",
      "title": "Happy Dance GIF by 100 Thieves",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2021-07-19 18:32:51",
      "trending_datetime": "2021-08-11 21:00:10",
      "images": {
        "original": {
          "height": "270",
          "width": "480",
          "size": "1792925",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "313592",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "360076",
          "webp": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "32",
          "hash": "bb70b1495980fe8e7182b5aef7c580fe"
        },
        "downsized": {
          "height": "270",
          "width": "480",
          "size": "1792925",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "270",
          "width": "480",
          "size": "1792925",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "270",
          "width": "480",
          "size": "1792925",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "202",
          "width": "359",
          "mp4_size": "122877",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "270",
          "width": "480",
          "size": "1792925",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "356",
          "size": "800602",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "208974",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "232670",
          "webp": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "356",
          "size": "161112",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "96802",
          "webp": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "178",
          "size": "280240",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "82675",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "94474",
          "webp": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "178",
          "size": "11295",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "356",
          "size": "26844",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "113",
          "width": "200",
          "size": "350049",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "94600",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "107764",
          "webp": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "113",
          "width": "200",
          "size": "65067",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "41042",
          "webp": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "57",
          "width": "100",
          "size": "112876",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "34770",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "40858",
          "webp": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "57",
          "width": "100",
          "size": "4473",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "113",
          "width": "200",
          "size": "13910",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3723808",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "270",
          "width": "480",
          "size": "78977",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "270",
          "width": "480",
          "mp4_size": "313592",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "108",
          "width": "192",
          "mp4_size": "42851",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "52",
          "width": "92",
          "size": "49617",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "86",
          "width": "152",
          "size": "42138",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "562",
          "width": "1000",
          "mp4_size": "1494676",
          "mp4": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "270",
          "width": "480",
          "size": "1792925",
          "url": "https://media2.giphy.com/media/LiUboYHPa1hf40XDRk/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media2.giphy.com/avatars/100Thieves/qmgr9h2u1XGL.png",
        "banner_image": "https://media2.giphy.com/headers/100Thieves/0QunQ4Av5rdz.png",
        "banner_url": "https://media2.giphy.com/headers/100Thieves/0QunQ4Av5rdz.png",
        "profile_url": "https://giphy.com/100Thieves/",
        "username": "100Thieves",
        "display_name": "100 Thieves",
        "description": "",
        "instagram_url": "https://instagram.com/100thieves",
        "website_url": "http://100thieves.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPUxpVWJvWUhQYTFoZjQwWERSayZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUxpVWJvWUhQYTFoZjQwWERSayZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUxpVWJvWUhQYTFoZjQwWERSayZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUxpVWJvWUhQYTFoZjQwWERSayZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "VjLFDdU89O3DsWE4Eh",
      "url": "https://giphy.com/gifs/thelonelyisland-the-lonely-island-i-think-you-should-leave-itysl-VjLFDdU89O3DsWE4Eh",
      "slug": "thelonelyisland-the-lonely-island-i-think-you-should-leave-itysl-VjLFDdU89O3DsWE4Eh",
      "bitly_gif_url": "https://gph.is/g/ZWJ07Kz",
      "bitly_url": "https://gph.is/g/ZWJ07Kz",
      "embed_url": "https://giphy.com/embed/VjLFDdU89O3DsWE4Eh",
      "username": "thelonelyisland",
      "source": "http://www.thelonelyisland.com/",
      "title": "Season 2 Smh GIF by The Lonely Island",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.thelonelyisland.com",
      "source_post_url": "http://www.thelonelyisland.com/",
      "is_sticker": 0,
      "import_datetime": "2021-07-02 01:39:30",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "360",
          "width": "480",
          "size": "5154472",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "659281",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "1092650",
          "webp": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "78",
          "hash": "463f53bee2a87a1e615d03437cfa4d92"
        },
        "downsized": {
          "height": "288",
          "width": "384",
          "size": "1703409",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "360",
          "width": "480",
          "size": "5154472",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "360",
          "width": "480",
          "size": "3413017",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy-downsized-medium.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-medium.gif&ct=g"
        },
        "downsized_small": {
          "height": "198",
          "width": "264",
          "mp4_size": "161059",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "288",
          "width": "384",
          "size": "35054",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "267",
          "size": "1394865",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "296867",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "562100",
          "webp": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "267",
          "size": "115149",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "70994",
          "webp": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "134",
          "size": "490517",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "129433",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "244846",
          "webp": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "134",
          "size": "7445",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "267",
          "size": "20114",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "150",
          "width": "200",
          "size": "1110595",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "208715",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "398028",
          "webp": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "150",
          "width": "200",
          "size": "101371",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "44102",
          "webp": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "75",
          "width": "100",
          "size": "317148",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48435",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "167376",
          "webp": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "75",
          "width": "100",
          "size": "4852",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "150",
          "width": "200",
          "size": "16100",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1775609",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "360",
          "width": "480",
          "size": "66634",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "360",
          "width": "480",
          "mp4_size": "659281",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "218",
          "width": "290",
          "mp4_size": "41561",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "61",
          "width": "81",
          "size": "49634",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "146",
          "width": "194",
          "size": "49786",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "900",
          "width": "1200",
          "mp4_size": "3279752",
          "mp4": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "360",
          "width": "480",
          "size": "5154472",
          "url": "https://media1.giphy.com/media/VjLFDdU89O3DsWE4Eh/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media2.giphy.com/avatars/thelonelyisland/xeKg7YHsR1mV.gif",
        "banner_image": "https://media2.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "banner_url": "https://media2.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "profile_url": "https://giphy.com/thelonelyisland/",
        "username": "thelonelyisland",
        "display_name": "The Lonely Island",
        "description": "",
        "instagram_url": "https://instagram.com/thelonelyisland",
        "website_url": "http://www.thelonelyisland.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPVZqTEZEZFU4OU8zRHNXRTRFaCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVZqTEZEZFU4OU8zRHNXRTRFaCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVZqTEZEZFU4OU8zRHNXRTRFaCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVZqTEZEZFU4OU8zRHNXRTRFaCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "fIsdUaLEh9Sy6sUpr3",
      "url": "https://giphy.com/gifs/wave-plasticpollution-dopper-fIsdUaLEh9Sy6sUpr3",
      "slug": "wave-plasticpollution-dopper-fIsdUaLEh9Sy6sUpr3",
      "bitly_gif_url": "https://gph.is/g/Z5GJ1Wo",
      "bitly_url": "https://gph.is/g/Z5GJ1Wo",
      "embed_url": "https://giphy.com/embed/fIsdUaLEh9Sy6sUpr3",
      "username": "Dopper",
      "source": "",
      "title": "Wave Ocean GIF by Dopper",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2021-01-20 10:59:29",
      "trending_datetime": "2021-08-11 20:07:50",
      "images": {
        "original": {
          "height": "480",
          "width": "480",
          "size": "1360470",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "305552",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "378914",
          "webp": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "16",
          "hash": "c9b5c919651958b17ad45ce4a9933e89"
        },
        "downsized": {
          "height": "480",
          "width": "480",
          "size": "1360470",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "480",
          "width": "480",
          "size": "1360470",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "480",
          "width": "480",
          "size": "1360470",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "322",
          "width": "322",
          "mp4_size": "65884",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "480",
          "width": "480",
          "size": "1360470",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "226233",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "61783",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "90944",
          "webp": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "125330",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "48316",
          "webp": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "79842",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "23129",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "36636",
          "webp": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "5611",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "14303",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "226233",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "61783",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "90944",
          "webp": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "125330",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "48316",
          "webp": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "79842",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "23129",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "36636",
          "webp": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "5611",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "14303",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "4078628",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "480",
          "size": "112425",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "305552",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "192",
          "width": "192",
          "mp4_size": "29660",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "74",
          "width": "74",
          "size": "47519",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "158",
          "width": "158",
          "size": "41758",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "1080",
          "width": "1080",
          "mp4_size": "4331193",
          "mp4": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "1360470",
          "url": "https://media4.giphy.com/media/fIsdUaLEh9Sy6sUpr3/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media1.giphy.com/avatars/Dopper/6K9ZrH3x7rXe.jpg",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/Dopper/",
        "username": "Dopper",
        "display_name": "Dopper",
        "description": "Join the wave against single-use plastic water bottles.",
        "instagram_url": "https://instagram.com/dopper_official",
        "website_url": "http://www.dopper.com",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPWZJc2RVYUxFaDlTeTZzVXByMyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWZJc2RVYUxFaDlTeTZzVXByMyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWZJc2RVYUxFaDlTeTZzVXByMyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWZJc2RVYUxFaDlTeTZzVXByMyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "qmCfDX2tAKBdF0ULCy",
      "url": "https://giphy.com/gifs/yevbel-goodnight-good-night-sweetdreams-qmCfDX2tAKBdF0ULCy",
      "slug": "yevbel-goodnight-good-night-sweetdreams-qmCfDX2tAKBdF0ULCy",
      "bitly_gif_url": "https://gph.is/g/460j3J9",
      "bitly_url": "https://gph.is/g/460j3J9",
      "embed_url": "https://giphy.com/embed/qmCfDX2tAKBdF0ULCy",
      "username": "yevbel",
      "source": "",
      "title": "Good Night Bedtime GIF by Yevbel",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2021-05-17 17:57:35",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "480",
          "width": "270",
          "size": "4865885",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "570039",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "1492114",
          "webp": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "108",
          "hash": "cc0759ea8bcb3a6fba82c1c842f21913"
        },
        "downsized": {
          "height": "480",
          "width": "270",
          "size": "1616599",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "480",
          "width": "270",
          "size": "4865885",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "480",
          "width": "270",
          "size": "4865885",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "284",
          "width": "159",
          "mp4_size": "133601",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "480",
          "width": "270",
          "size": "37335",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "113",
          "size": "973762",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "170751",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "515728",
          "webp": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "113",
          "size": "77996",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "44316",
          "webp": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "57",
          "size": "301717",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "58057",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "190550",
          "webp": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "57",
          "size": "3974",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "113",
          "size": "11510",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "356",
          "width": "200",
          "size": "2317240",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "380751",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "1097018",
          "webp": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "356",
          "width": "200",
          "size": "147062",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "108852",
          "webp": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "178",
          "width": "100",
          "size": "903374",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "46824",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "447298",
          "webp": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "178",
          "width": "100",
          "size": "9479",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "356",
          "width": "200",
          "size": "21065",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1112081",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "270",
          "size": "46413",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "270",
          "mp4_size": "570039",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "384",
          "width": "216",
          "mp4_size": "27876",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "106",
          "width": "60",
          "size": "48031",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "176",
          "width": "100",
          "size": "40506",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "1080",
          "width": "608",
          "mp4_size": "1747721",
          "mp4": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "853",
          "width": "480",
          "size": "4865885",
          "url": "https://media2.giphy.com/media/qmCfDX2tAKBdF0ULCy/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media4.giphy.com/avatars/yevbel/WFkxSurRcMYO.gif",
        "banner_image": "https://media4.giphy.com/headers/yevbel/VGARrAgXjnQ6.gif",
        "banner_url": "https://media4.giphy.com/headers/yevbel/VGARrAgXjnQ6.gif",
        "profile_url": "https://giphy.com/yevbel/",
        "username": "yevbel",
        "display_name": "Yevbel",
        "description": "",
        "instagram_url": "https://instagram.com/yevbel",
        "website_url": "",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPXFtQ2ZEWDJ0QUtCZEYwVUxDeSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXFtQ2ZEWDJ0QUtCZEYwVUxDeSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXFtQ2ZEWDJ0QUtCZEYwVUxDeSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXFtQ2ZEWDJ0QUtCZEYwVUxDeSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "l0XQbzGsATrRXXmjUD",
      "url": "https://giphy.com/gifs/moodman-happy-birthday-weird-l0XQbzGsATrRXXmjUD",
      "slug": "moodman-happy-birthday-weird-l0XQbzGsATrRXXmjUD",
      "bitly_gif_url": "https://gph.is/g/ZPmYgG8",
      "bitly_url": "https://gph.is/g/ZPmYgG8",
      "embed_url": "https://giphy.com/embed/l0XQbzGsATrRXXmjUD",
      "username": "",
      "source": "https://media.giphy.com/media/dhe7aatheWD4Y/giphy.gif",
      "title": "Happy Birthday Bday GIF by MOODMAN",
      "rating": "g",
      "content_url": "",
      "source_tld": "media.giphy.com",
      "source_post_url": "https://media.giphy.com/media/dhe7aatheWD4Y/giphy.gif",
      "is_sticker": 0,
      "import_datetime": "2020-02-24 20:20:08",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "480",
          "width": "480",
          "size": "3354259",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "659760",
          "mp4": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "762112",
          "webp": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "45",
          "hash": "a10908298059556c51b3f6b2e95945de"
        },
        "downsized": {
          "height": "384",
          "width": "384",
          "size": "1583328",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "480",
          "width": "480",
          "size": "3354259",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "480",
          "width": "480",
          "size": "3354259",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "264",
          "width": "264",
          "mp4_size": "135271",
          "mp4": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "384",
          "width": "384",
          "size": "40761",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "618143",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "152682",
          "mp4": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "270712",
          "webp": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "121302",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "66158",
          "webp": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "194325",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "54526",
          "mp4": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "112598",
          "webp": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "6006",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "16760",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "618143",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "152682",
          "mp4": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "270712",
          "webp": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "121302",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "66158",
          "webp": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "194325",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "50080",
          "mp4": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "112598",
          "webp": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "6006",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "16760",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3104386",
          "mp4": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "480",
          "size": "101091",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "659760",
          "mp4": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "218",
          "width": "218",
          "mp4_size": "42238",
          "mp4": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "88",
          "width": "88",
          "size": "48957",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "118",
          "width": "118",
          "size": "31002",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "3354259",
          "url": "https://media0.giphy.com/media/l0XQbzGsATrRXXmjUD/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPWwwWFFiekdzQVRyUlhYbWpVRCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWwwWFFiekdzQVRyUlhYbWpVRCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWwwWFFiekdzQVRyUlhYbWpVRCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWwwWFFiekdzQVRyUlhYbWpVRCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "8FcLLFD8z0C1lkUTmY",
      "url": "https://giphy.com/gifs/mlb-baseball-all-star-2018-8FcLLFD8z0C1lkUTmY",
      "slug": "mlb-baseball-all-star-2018-8FcLLFD8z0C1lkUTmY",
      "bitly_gif_url": "https://gph.is/2O3t6vY",
      "bitly_url": "https://gph.is/2O3t6vY",
      "embed_url": "https://giphy.com/embed/8FcLLFD8z0C1lkUTmY",
      "username": "mlb",
      "source": "mlb.com",
      "title": "atlanta braves sport GIF by MLB",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "mlb.com",
      "is_sticker": 0,
      "import_datetime": "2018-08-01 17:04:15",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "270",
          "width": "480",
          "size": "1260859",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "156537",
          "mp4": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "275700",
          "webp": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "56",
          "hash": "dc1f987be9f764f7bf1f9ccdf45b772a"
        },
        "downsized": {
          "height": "270",
          "width": "480",
          "size": "1260859",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "270",
          "width": "480",
          "size": "1260859",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "270",
          "width": "480",
          "size": "1260859",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "270",
          "width": "480",
          "mp4_size": "163162",
          "mp4": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "270",
          "width": "480",
          "size": "1260859",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "356",
          "size": "632511",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "95388",
          "mp4": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "176472",
          "webp": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "356",
          "size": "74109",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "44454",
          "webp": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "178",
          "size": "199892",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "32447",
          "mp4": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "65798",
          "webp": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "178",
          "size": "4805",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "356",
          "size": "13910",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "113",
          "width": "200",
          "size": "226791",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "37869",
          "mp4": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "77616",
          "webp": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "113",
          "width": "200",
          "size": "29494",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "18306",
          "webp": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "57",
          "width": "100",
          "size": "74708",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "13388",
          "mp4": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "29870",
          "webp": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "57",
          "width": "100",
          "size": "2444",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "113",
          "width": "200",
          "size": "5620",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1302919",
          "mp4": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "270",
          "width": "480",
          "size": "33926",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "270",
          "width": "480",
          "mp4_size": "156537",
          "mp4": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "148",
          "width": "263",
          "mp4_size": "26322",
          "mp4": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "86",
          "width": "153",
          "size": "49148",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "152",
          "width": "270",
          "size": "45062",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "270",
          "width": "480",
          "size": "1260859",
          "url": "https://media0.giphy.com/media/8FcLLFD8z0C1lkUTmY/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media2.giphy.com/avatars/mlb/UTAk9uV8rZw2.jpg",
        "banner_image": "https://media2.giphy.com/channel_assets/mlb/8Y39J0Q4HSYL.gif",
        "banner_url": "https://media2.giphy.com/channel_assets/mlb/8Y39J0Q4HSYL.gif",
        "profile_url": "https://giphy.com/mlb/",
        "username": "mlb",
        "display_name": "MLB",
        "description": "Every GIF from every game of MLB! Find and share all of your favorite moments!",
        "instagram_url": "https://instagram.com/mlb",
        "website_url": "http://mlb.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPThGY0xMRkQ4ejBDMWxrVVRtWSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPThGY0xMRkQ4ejBDMWxrVVRtWSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPThGY0xMRkQ4ejBDMWxrVVRtWSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPThGY0xMRkQ4ejBDMWxrVVRtWSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "Q7FX6k1GZ5eLxC7dMQ",
      "url": "https://giphy.com/gifs/murcianys-radiomurcianyshn-yesymurcianyshn-albita-Q7FX6k1GZ5eLxC7dMQ",
      "slug": "murcianys-radiomurcianyshn-yesymurcianyshn-albita-Q7FX6k1GZ5eLxC7dMQ",
      "bitly_gif_url": "https://gph.is/g/aRMKvlN",
      "bitly_url": "https://gph.is/g/aRMKvlN",
      "embed_url": "https://giphy.com/embed/Q7FX6k1GZ5eLxC7dMQ",
      "username": "murcianys",
      "source": "chatmurcianys.com",
      "title": "Happy I Love You GIF by murcianys",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "chatmurcianys.com",
      "is_sticker": 0,
      "import_datetime": "2020-05-26 01:25:43",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "480",
          "width": "464",
          "size": "510127",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "98198",
          "mp4": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "145534",
          "webp": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "15",
          "hash": "38d4df097b6005fcc22749ae0ec29d99"
        },
        "downsized": {
          "height": "480",
          "width": "464",
          "size": "510127",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "480",
          "width": "464",
          "size": "510127",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "480",
          "width": "464",
          "size": "510127",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "480",
          "width": "464",
          "mp4_size": "98198",
          "mp4": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "480",
          "width": "464",
          "size": "510127",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "193",
          "size": "107055",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "24774",
          "mp4": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "56166",
          "webp": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "193",
          "size": "45388",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "28750",
          "webp": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "97",
          "size": "35271",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "10550",
          "mp4": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "23904",
          "webp": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "97",
          "size": "3373",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "193",
          "size": "9476",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "207",
          "width": "200",
          "size": "124304",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "25342",
          "mp4": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "57986",
          "webp": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "207",
          "width": "200",
          "size": "52489",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "30426",
          "webp": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "104",
          "width": "100",
          "size": "38612",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "11580",
          "mp4": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "25334",
          "webp": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "104",
          "width": "100",
          "size": "3576",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "207",
          "width": "200",
          "size": "9163",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1356230",
          "mp4": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "464",
          "size": "38660",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "464",
          "mp4_size": "98198",
          "mp4": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "342",
          "width": "330",
          "mp4_size": "29630",
          "mp4": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "105",
          "width": "102",
          "size": "49192",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "242",
          "width": "234",
          "size": "46642",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "497",
          "width": "480",
          "size": "510127",
          "url": "https://media2.giphy.com/media/Q7FX6k1GZ5eLxC7dMQ/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/murcianys/I4o802CNVWTP.png",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/murcianys/",
        "username": "murcianys",
        "display_name": "murcianys",
        "description": "Listen to your favorite radio stations while you chat and request songs.",
        "instagram_url": "",
        "website_url": "https://chatmurcianys.com",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPVE3Rlg2azFHWjVlTHhDN2RNUSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVE3Rlg2azFHWjVlTHhDN2RNUSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVE3Rlg2azFHWjVlTHhDN2RNUSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVE3Rlg2azFHWjVlTHhDN2RNUSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "S3Ot3hZ5bcy8o",
      "url": "https://giphy.com/gifs/jack-nicholson-nodding-anger-management-S3Ot3hZ5bcy8o",
      "slug": "jack-nicholson-nodding-anger-management-S3Ot3hZ5bcy8o",
      "bitly_gif_url": "http://gph.is/Zfh9X7",
      "bitly_url": "http://gph.is/Zfh9X7",
      "embed_url": "https://giphy.com/embed/S3Ot3hZ5bcy8o",
      "username": "",
      "source": "http://www.neogaf.com/forum/showthread.php?p=47039900",
      "title": "Jack Nicholson Reaction GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.neogaf.com",
      "source_post_url": "http://www.neogaf.com/forum/showthread.php?p=47039900",
      "is_sticker": 0,
      "import_datetime": "2013-05-29 19:04:33",
      "trending_datetime": "2021-07-01 08:00:10",
      "images": {
        "original": {
          "height": "263",
          "width": "337",
          "size": "2588701",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "797589",
          "mp4": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "413014",
          "webp": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "75",
          "hash": "670a5204c8a089c907ea000abffdaa92"
        },
        "downsized": {
          "height": "263",
          "width": "337",
          "size": "1181144",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "263",
          "width": "337",
          "size": "2588701",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "263",
          "width": "337",
          "size": "2588701",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "188",
          "width": "241",
          "mp4_size": "41766",
          "mp4": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "263",
          "width": "337",
          "size": "16326",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "256",
          "size": "1177536",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "124811",
          "mp4": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "219262",
          "webp": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "256",
          "size": "96779",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "54378",
          "webp": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "128",
          "size": "335396",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "35853",
          "mp4": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "68524",
          "webp": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "128",
          "size": "5088",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "256",
          "size": "15004",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "156",
          "width": "200",
          "size": "768762",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "72853",
          "mp4": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "139512",
          "webp": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "156",
          "width": "200",
          "size": "60147",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "35122",
          "webp": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "78",
          "width": "100",
          "size": "228590",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "24629",
          "mp4": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "48144",
          "webp": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "78",
          "width": "100",
          "size": "3724",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "156",
          "width": "200",
          "size": "14288",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3107466",
          "mp4": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "263",
          "width": "337",
          "size": "48889",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "374",
          "width": "480",
          "mp4_size": "797589",
          "mp4": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "208",
          "width": "266",
          "mp4_size": "37811",
          "mp4": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "60",
          "width": "77",
          "size": "48302",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "114",
          "width": "146",
          "size": "22926",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "375",
          "width": "480",
          "size": "2588701",
          "url": "https://media1.giphy.com/media/S3Ot3hZ5bcy8o/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPVMzT3QzaFo1YmN5OG8mZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVMzT3QzaFo1YmN5OG8mZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVMzT3QzaFo1YmN5OG8mZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVMzT3QzaFo1YmN5OG8mZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "Hc8PMCBjo9BXa",
      "url": "https://giphy.com/gifs/applause-laughing-Hc8PMCBjo9BXa",
      "slug": "applause-laughing-Hc8PMCBjo9BXa",
      "bitly_gif_url": "http://gph.is/1eQxM4i",
      "bitly_url": "http://gph.is/1eQxM4i",
      "embed_url": "https://giphy.com/embed/Hc8PMCBjo9BXa",
      "username": "",
      "source": "http://www.tumblr.com",
      "title": "Well Done Reaction GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.tumblr.com",
      "source_post_url": "http://www.tumblr.com",
      "is_sticker": 0,
      "import_datetime": "2014-02-12 19:11:22",
      "trending_datetime": "2020-08-19 11:30:10",
      "images": {
        "original": {
          "height": "438",
          "width": "306",
          "size": "84899",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "97089",
          "mp4": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "55048",
          "webp": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "2",
          "hash": "b7742ab628ab7caa12cab503b8e3c7ce"
        },
        "downsized": {
          "height": "438",
          "width": "306",
          "size": "84899",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "438",
          "width": "306",
          "size": "84899",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "438",
          "width": "306",
          "size": "84899",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "438",
          "width": "306",
          "mp4_size": "57851",
          "mp4": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "438",
          "width": "306",
          "size": "84899",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "140",
          "size": "21161",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "11910",
          "mp4": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "12282",
          "webp": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "140",
          "size": "21161",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "13058",
          "webp": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "70",
          "size": "6815",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "4326",
          "mp4": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "3938",
          "webp": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "70",
          "size": "5452",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "140",
          "size": "17065",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "286",
          "width": "200",
          "size": "40171",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "22237",
          "mp4": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "23742",
          "webp": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "286",
          "width": "200",
          "size": "40171",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "25340",
          "webp": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "143",
          "width": "100",
          "size": "11971",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "6871",
          "mp4": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "6932",
          "webp": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "143",
          "width": "100",
          "size": "11348",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "286",
          "width": "200",
          "size": "32667",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3642329",
          "mp4": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "438",
          "width": "306",
          "size": "67657",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "686",
          "width": "480",
          "mp4_size": "97089",
          "mp4": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "394",
          "width": "275",
          "mp4_size": "27043",
          "mp4": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "229",
          "width": "160",
          "size": "48645",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "406",
          "width": "284",
          "size": "45326",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "687",
          "width": "480",
          "size": "84899",
          "url": "https://media3.giphy.com/media/Hc8PMCBjo9BXa/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPUhjOFBNQ0JqbzlCWGEmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUhjOFBNQ0JqbzlCWGEmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUhjOFBNQ0JqbzlCWGEmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUhjOFBNQ0JqbzlCWGEmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "TKLjfZ9npAKaanNGK9",
      "url": "https://giphy.com/gifs/memecandy-TKLjfZ9npAKaanNGK9",
      "slug": "memecandy-TKLjfZ9npAKaanNGK9",
      "bitly_gif_url": "https://gph.is/g/aXYGm7e",
      "bitly_url": "https://gph.is/g/aXYGm7e",
      "embed_url": "https://giphy.com/embed/TKLjfZ9npAKaanNGK9",
      "username": "memecandy",
      "source": "",
      "title": "Sweet Dreams GIF by memecandy",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2019-12-11 23:45:47",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "342",
          "width": "260",
          "size": "1508363",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "1565985",
          "mp4": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "951418",
          "webp": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "61",
          "hash": "ad93ada557f6ff72f8bba8319983308e"
        },
        "downsized": {
          "height": "342",
          "width": "260",
          "size": "1508363",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "342",
          "width": "260",
          "size": "1508363",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "342",
          "width": "260",
          "size": "1508363",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "184",
          "width": "139",
          "mp4_size": "20952",
          "mp4": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "342",
          "width": "260",
          "size": "1508363",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "152",
          "size": "473288",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "52093",
          "mp4": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "343580",
          "webp": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "152",
          "size": "55163",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "47778",
          "webp": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "76",
          "size": "145977",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "12906",
          "mp4": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "127452",
          "webp": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "76",
          "size": "3384",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "152",
          "size": "9901",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "263",
          "width": "200",
          "size": "897886",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "128781",
          "mp4": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "539120",
          "webp": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "263",
          "width": "200",
          "size": "94676",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "77028",
          "webp": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "132",
          "width": "100",
          "size": "240453",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "22201",
          "mp4": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "176906",
          "webp": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "132",
          "width": "100",
          "size": "4923",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "263",
          "width": "200",
          "size": "14939",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3208917",
          "mp4": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "342",
          "width": "260",
          "size": "30088",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "630",
          "width": "480",
          "mp4_size": "1565985",
          "mp4": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "222",
          "width": "168",
          "mp4_size": "32521",
          "mp4": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "95",
          "width": "72",
          "size": "46371",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "112",
          "width": "86",
          "size": "26342",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "631",
          "width": "480",
          "size": "1508363",
          "url": "https://media2.giphy.com/media/TKLjfZ9npAKaanNGK9/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media3.giphy.com/avatars/default5.gif",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/memecandy/",
        "username": "memecandy",
        "display_name": "",
        "description": "",
        "instagram_url": "",
        "website_url": "",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPVRLTGpmWjlucEFLYWFuTkdLOSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRLTGpmWjlucEFLYWFuTkdLOSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRLTGpmWjlucEFLYWFuTkdLOSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRLTGpmWjlucEFLYWFuTkdLOSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "kgeJaaNzMJfk4jivMy",
      "url": "https://giphy.com/gifs/MGMStudios-mgm-studios-summer-days-nights-kgeJaaNzMJfk4jivMy",
      "slug": "MGMStudios-mgm-studios-summer-days-nights-kgeJaaNzMJfk4jivMy",
      "bitly_gif_url": "https://gph.is/g/ZWbMoxX",
      "bitly_url": "https://gph.is/g/ZWbMoxX",
      "embed_url": "https://giphy.com/embed/kgeJaaNzMJfk4jivMy",
      "username": "MGMStudios",
      "source": "https://youtu.be/-XHi5ZxfPHY",
      "title": "Mind Your Own Business GIF by MGM Studios",
      "rating": "g",
      "content_url": "",
      "source_tld": "youtu.be",
      "source_post_url": "https://youtu.be/-XHi5ZxfPHY",
      "is_sticker": 0,
      "import_datetime": "2021-08-10 20:21:47",
      "trending_datetime": "2021-08-11 20:00:37",
      "images": {
        "original": {
          "height": "360",
          "width": "480",
          "size": "979512",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "80236",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "193662",
          "webp": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "23",
          "hash": "05d3c9f49c0b245c5ed5548e235f59b7"
        },
        "downsized": {
          "height": "360",
          "width": "480",
          "size": "979512",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "360",
          "width": "480",
          "size": "979512",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "360",
          "width": "480",
          "size": "979512",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "360",
          "width": "480",
          "mp4_size": "80236",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "360",
          "width": "480",
          "size": "979512",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "267",
          "size": "294765",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "35144",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "119284",
          "webp": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "267",
          "size": "108315",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "71782",
          "webp": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "134",
          "size": "109832",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "16006",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "56768",
          "webp": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "134",
          "size": "6580",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "267",
          "size": "16697",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "150",
          "width": "200",
          "size": "193957",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "24500",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "88340",
          "webp": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "150",
          "width": "200",
          "size": "71299",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "48014",
          "webp": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "75",
          "width": "100",
          "size": "71342",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "10792",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "39838",
          "webp": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "75",
          "width": "100",
          "size": "4483",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "150",
          "width": "200",
          "size": "14679",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "742996",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "360",
          "width": "480",
          "size": "56493",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "360",
          "width": "480",
          "mp4_size": "80236",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "282",
          "width": "376",
          "mp4_size": "28625",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "72",
          "width": "96",
          "size": "49846",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "168",
          "width": "224",
          "size": "49362",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "900",
          "width": "1200",
          "mp4_size": "360066",
          "mp4": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "360",
          "width": "480",
          "size": "979512",
          "url": "https://media1.giphy.com/media/kgeJaaNzMJfk4jivMy/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/mgm_studios/qjNG9khlgx1o.jpg",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/MGMStudios/",
        "username": "MGMStudios",
        "display_name": "MGM Studios",
        "description": "Welcome to the official Giphy page for MGM Studios.",
        "instagram_url": "https://instagram.com/MGMStudios",
        "website_url": "http://www.mgm.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPWtnZUphYU56TUpmazRqaXZNeSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWtnZUphYU56TUpmazRqaXZNeSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWtnZUphYU56TUpmazRqaXZNeSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWtnZUphYU56TUpmazRqaXZNeSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "dViyJUVrOsG5zyVsiP",
      "url": "https://giphy.com/gifs/thelonelyisland-i-think-you-should-leave-lonelyisland-itysl-dViyJUVrOsG5zyVsiP",
      "slug": "thelonelyisland-i-think-you-should-leave-lonelyisland-itysl-dViyJUVrOsG5zyVsiP",
      "bitly_gif_url": "https://gph.is/g/4o6o130",
      "bitly_url": "https://gph.is/g/4o6o130",
      "embed_url": "https://giphy.com/embed/dViyJUVrOsG5zyVsiP",
      "username": "thelonelyisland",
      "source": "www.thelonelyisland.com",
      "title": "You Suck Cecily Strong GIF by The Lonely Island",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "www.thelonelyisland.com",
      "is_sticker": 0,
      "import_datetime": "2019-08-08 18:03:28",
      "trending_datetime": "2019-08-12 17:15:02",
      "images": {
        "original": {
          "height": "320",
          "width": "480",
          "size": "1444271",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "192891",
          "mp4": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "296418",
          "webp": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "37",
          "hash": "c0839494db9044213571cb8e3c447139"
        },
        "downsized": {
          "height": "320",
          "width": "480",
          "size": "1444271",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "320",
          "width": "480",
          "size": "1444271",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "320",
          "width": "480",
          "size": "1444271",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "320",
          "width": "480",
          "mp4_size": "192891",
          "mp4": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "320",
          "width": "480",
          "size": "1444271",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "300",
          "size": "498050",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "80369",
          "mp4": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "167306",
          "webp": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "300",
          "size": "86872",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "56408",
          "webp": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "150",
          "size": "176180",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "30561",
          "mp4": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "76164",
          "webp": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "150",
          "size": "4938",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "300",
          "size": "13146",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "133",
          "width": "200",
          "size": "276077",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "45563",
          "mp4": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "105986",
          "webp": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "133",
          "width": "200",
          "size": "47054",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "30402",
          "webp": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "67",
          "width": "100",
          "size": "97778",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "18748",
          "mp4": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "50078",
          "webp": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "67",
          "width": "100",
          "size": "3088",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "133",
          "width": "200",
          "size": "8025",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1174307",
          "mp4": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "320",
          "width": "480",
          "size": "67046",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "320",
          "width": "480",
          "mp4_size": "192891",
          "mp4": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "256",
          "width": "384",
          "mp4_size": "36128",
          "mp4": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "58",
          "width": "87",
          "size": "48802",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "224",
          "width": "336",
          "size": "44134",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "320",
          "width": "480",
          "size": "1444271",
          "url": "https://media0.giphy.com/media/dViyJUVrOsG5zyVsiP/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/thelonelyisland/xeKg7YHsR1mV.gif",
        "banner_image": "https://media0.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "banner_url": "https://media0.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "profile_url": "https://giphy.com/thelonelyisland/",
        "username": "thelonelyisland",
        "display_name": "The Lonely Island",
        "description": "",
        "instagram_url": "https://instagram.com/thelonelyisland",
        "website_url": "http://www.thelonelyisland.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPWRWaXlKVVZyT3NHNXp5VnNpUCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWRWaXlKVVZyT3NHNXp5VnNpUCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWRWaXlKVVZyT3NHNXp5VnNpUCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWRWaXlKVVZyT3NHNXp5VnNpUCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "QrhV2RTdTc4il2CUJK",
      "url": "https://giphy.com/gifs/SVT-svt-play-bst-i-test-QrhV2RTdTc4il2CUJK",
      "slug": "SVT-svt-play-bst-i-test-QrhV2RTdTc4il2CUJK",
      "bitly_gif_url": "https://gph.is/g/am1wejQ",
      "bitly_url": "https://gph.is/g/am1wejQ",
      "embed_url": "https://giphy.com/embed/QrhV2RTdTc4il2CUJK",
      "username": "SVT",
      "source": "https://www.svtplay.se/bast-i-test",
      "title": "Test Wave GIF by SVT",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.svtplay.se",
      "source_post_url": "https://www.svtplay.se/bast-i-test",
      "is_sticker": 0,
      "import_datetime": "2021-02-17 15:28:25",
      "trending_datetime": "2021-08-11 19:49:32",
      "images": {
        "original": {
          "height": "480",
          "width": "480",
          "size": "12190635",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "958626",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "3086440",
          "webp": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "105",
          "hash": "c708a0b0012602f0eb4b6d66e8f348b7"
        },
        "downsized": {
          "height": "240",
          "width": "240",
          "size": "1282971",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "384",
          "width": "384",
          "size": "6225153",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-downsized-large.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-large.gif&ct=g"
        },
        "downsized_medium": {
          "height": "366",
          "width": "366",
          "size": "4425397",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-downsized-medium.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-medium.gif&ct=g"
        },
        "downsized_small": {
          "height": "192",
          "width": "192",
          "mp4_size": "106118",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "240",
          "width": "240",
          "size": "27211",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "1766068",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "219398",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "664926",
          "webp": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "147924",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "82454",
          "webp": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "576433",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "76381",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "212128",
          "webp": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "7673",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "23364",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "1766068",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "219398",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "664926",
          "webp": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "147924",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "82454",
          "webp": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "576433",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48942",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "212128",
          "webp": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "7673",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "23364",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "6288743",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "480",
          "size": "180580",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "958626",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "206",
          "width": "206",
          "mp4_size": "38747",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "80",
          "width": "80",
          "size": "48295",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "82",
          "width": "82",
          "size": "20034",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "1080",
          "width": "1080",
          "mp4_size": "18392151",
          "mp4": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "12190635",
          "url": "https://media4.giphy.com/media/QrhV2RTdTc4il2CUJK/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media3.giphy.com/avatars/sverigestelevision/izObQMfvTBnx.gif",
        "banner_image": "https://media3.giphy.com/headers/sverigestelevision/bdnR1ysWdv5l.jpg",
        "banner_url": "https://media3.giphy.com/headers/sverigestelevision/bdnR1ysWdv5l.jpg",
        "profile_url": "https://giphy.com/SVT/",
        "username": "SVT",
        "display_name": "SVT",
        "description": "SVT är ett public service-företag vars uppdrag vilar på en demokratisk idé. Vi gör tv om alla, för alla.",
        "instagram_url": "https://instagram.com/svt",
        "website_url": "https://www.svtplay.se/",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPVFyaFYyUlRkVGM0aWwyQ1VKSyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVFyaFYyUlRkVGM0aWwyQ1VKSyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVFyaFYyUlRkVGM0aWwyQ1VKSyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVFyaFYyUlRkVGM0aWwyQ1VKSyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "VIPdgcooFJHtC",
      "url": "https://giphy.com/gifs/cat-kitten-gato-VIPdgcooFJHtC",
      "slug": "cat-kitten-gato-VIPdgcooFJHtC",
      "bitly_gif_url": "http://gph.is/XMh9hO",
      "bitly_url": "http://gph.is/XMh9hO",
      "embed_url": "https://giphy.com/embed/VIPdgcooFJHtC",
      "username": "",
      "source": "http://ozopanda.tumblr.com/post/46043210509",
      "title": "Good Night Reaction GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "ozopanda.tumblr.com",
      "source_post_url": "http://ozopanda.tumblr.com/post/46043210509",
      "is_sticker": 0,
      "import_datetime": "2013-03-23 12:08:38",
      "trending_datetime": "2021-05-17 04:30:05",
      "images": {
        "original": {
          "height": "214",
          "width": "275",
          "size": "1420693",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "1275163",
          "mp4": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "567820",
          "webp": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "31",
          "hash": "0c8ed3da07d4d436c2cac860f2dce760"
        },
        "downsized": {
          "height": "214",
          "width": "275",
          "size": "1420693",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "214",
          "width": "275",
          "size": "1420693",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "214",
          "width": "275",
          "size": "1420693",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "134",
          "width": "171",
          "mp4_size": "65416",
          "mp4": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "214",
          "width": "275",
          "size": "1420693",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "257",
          "size": "959494",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "374275",
          "mp4": "https://media3.giphy.com/media/VIPdgcooFJHtC/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "499724",
          "webp": "https://media3.giphy.com/media/VIPdgcooFJHtC/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "257",
          "size": "189472",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "103226",
          "webp": "https://media3.giphy.com/media/VIPdgcooFJHtC/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "129",
          "size": "252250",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "76104",
          "mp4": "https://media3.giphy.com/media/VIPdgcooFJHtC/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "138230",
          "webp": "https://media3.giphy.com/media/VIPdgcooFJHtC/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "129",
          "size": "9573",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "257",
          "size": "32449",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "156",
          "width": "200",
          "size": "598310",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "226455",
          "mp4": "https://media3.giphy.com/media/VIPdgcooFJHtC/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "325364",
          "webp": "https://media3.giphy.com/media/VIPdgcooFJHtC/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "156",
          "width": "200",
          "size": "121114",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "66442",
          "webp": "https://media3.giphy.com/media/VIPdgcooFJHtC/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "78",
          "width": "100",
          "size": "153934",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "39700",
          "mp4": "https://media3.giphy.com/media/VIPdgcooFJHtC/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "88754",
          "webp": "https://media3.giphy.com/media/VIPdgcooFJHtC/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "78",
          "width": "100",
          "size": "5671",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "156",
          "width": "200",
          "size": "19448",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "6911525",
          "mp4": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "214",
          "width": "275",
          "size": "48136",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "372",
          "width": "480",
          "mp4_size": "1275163",
          "mp4": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "116",
          "width": "148",
          "mp4_size": "43761",
          "mp4": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "63",
          "width": "81",
          "size": "49784",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "84",
          "width": "108",
          "size": "32590",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "374",
          "width": "480",
          "size": "1420693",
          "url": "https://media3.giphy.com/media/VIPdgcooFJHtC/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPVZJUGRnY29vRkpIdEMmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVZJUGRnY29vRkpIdEMmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVZJUGRnY29vRkpIdEMmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVZJUGRnY29vRkpIdEMmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "26FPsOhR3tyQRTc2Y",
      "url": "https://giphy.com/gifs/birthday-happy-birthday-celebrate-mashup-26FPsOhR3tyQRTc2Y",
      "slug": "birthday-happy-birthday-celebrate-mashup-26FPsOhR3tyQRTc2Y",
      "bitly_gif_url": "http://gph.is/1Qx1wAC",
      "bitly_url": "http://gph.is/1Qx1wAC",
      "embed_url": "https://giphy.com/embed/26FPsOhR3tyQRTc2Y",
      "username": "birthday",
      "source": "giphy.com",
      "title": "celebrate happy birthday GIF by Birthday Bot",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "giphy.com",
      "is_sticker": 0,
      "import_datetime": "2016-02-22 17:01:09",
      "trending_datetime": "2017-08-09 13:15:01",
      "images": {
        "original": {
          "height": "375",
          "width": "500",
          "size": "488982",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "128498",
          "mp4": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "273184",
          "webp": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "9",
          "hash": "ae49a33834f4cc3f0c2ee424b4a16f0e"
        },
        "downsized": {
          "height": "375",
          "width": "500",
          "size": "488982",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "375",
          "width": "500",
          "size": "488982",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "375",
          "width": "500",
          "size": "488982",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "374",
          "width": "500",
          "mp4_size": "164233",
          "mp4": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "375",
          "width": "500",
          "size": "488982",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "267",
          "size": "155000",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "24520",
          "mp4": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "61560",
          "webp": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "267",
          "size": "111987",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "73732",
          "webp": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "134",
          "size": "51900",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "8823",
          "mp4": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "23666",
          "webp": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "134",
          "size": "6960",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "267",
          "size": "19297",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "150",
          "width": "200",
          "size": "114626",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "15056",
          "mp4": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "41254",
          "webp": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "150",
          "width": "200",
          "size": "75583",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "47264",
          "webp": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "75",
          "width": "100",
          "size": "33286",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "6049",
          "mp4": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "16592",
          "webp": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "75",
          "width": "100",
          "size": "4560",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "150",
          "width": "200",
          "size": "14737",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2411211",
          "mp4": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "375",
          "width": "500",
          "size": "101000",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "360",
          "width": "480",
          "mp4_size": "128498",
          "mp4": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "204",
          "width": "272",
          "mp4_size": "13294",
          "mp4": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "77",
          "width": "103",
          "size": "48821",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "128",
          "width": "170",
          "size": "23844",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "360",
          "width": "480",
          "size": "488982",
          "url": "https://media1.giphy.com/media/26FPsOhR3tyQRTc2Y/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media1.giphy.com/avatars/birthday/kwJOeGSDDUuR.gif",
        "banner_image": "https://media1.giphy.com/headers/birthday/29JDUE2wgQK3.gif",
        "banner_url": "https://media1.giphy.com/headers/birthday/29JDUE2wgQK3.gif",
        "profile_url": "https://giphy.com/birthday/",
        "username": "birthday",
        "display_name": "Birthday Bot",
        "description": "Giphy's top engineers have worked day and night to bring you the cutting edge in partying technology: BIRTHDAY BOT.  He's been programmed to celebrate birthdays in a way humans can only imagine. Want to join in Giphy's birthday fun? Enter our #GiphyBirthdayBash contest and learn more here: http://giphy.com/posts/giphy-cams-new-birthday-filters-let-you-join-our-birthday-party",
        "instagram_url": "",
        "website_url": "http://giphy.com/posts/giphy-cams-new-birthday-filters-let-you-join-our-birthday-party",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPTI2RlBzT2hSM3R5UVJUYzJZJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTI2RlBzT2hSM3R5UVJUYzJZJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTI2RlBzT2hSM3R5UVJUYzJZJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTI2RlBzT2hSM3R5UVJUYzJZJmV2ZW50X3R5cGU9R0lGX1RSRU5ESU5HJmNpZD1iNGFiMDg1NWM4dDVxa3JqbWw0cDhyOTI4MHhpaXl2Y2hjcjBhNmlobmgyaWplanAmY3Q9Z2lm&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "JXXyd5GaGHMjA1pj3n",
      "url": "https://giphy.com/gifs/i-love-you-red-rose-and-heart-JXXyd5GaGHMjA1pj3n",
      "slug": "i-love-you-red-rose-and-heart-JXXyd5GaGHMjA1pj3n",
      "bitly_gif_url": "https://gph.is/g/ZPqD0qV",
      "bitly_url": "https://gph.is/g/ZPqD0qV",
      "embed_url": "https://giphy.com/embed/JXXyd5GaGHMjA1pj3n",
      "username": "dotdave",
      "source": "https://www.3danimatedgifs.com/",
      "title": "I Love You Spinning Heart GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.3danimatedgifs.com",
      "source_post_url": "https://www.3danimatedgifs.com/",
      "is_sticker": 0,
      "import_datetime": "2020-11-03 09:42:09",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "400",
          "width": "400",
          "size": "1396171",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "792326",
          "mp4": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "792516",
          "webp": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "48",
          "hash": "03761239f5cf1b3748e0572ab4d66e8c"
        },
        "downsized": {
          "height": "400",
          "width": "400",
          "size": "1396171",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "400",
          "width": "400",
          "size": "1396171",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "400",
          "width": "400",
          "size": "1396171",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "212",
          "width": "212",
          "mp4_size": "90254",
          "mp4": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "400",
          "width": "400",
          "size": "1396171",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "425060",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "142207",
          "mp4": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "250418",
          "webp": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "54811",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "43366",
          "webp": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "158859",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "57816",
          "mp4": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "105624",
          "webp": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "4398",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "9893",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "425060",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "142207",
          "mp4": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "250418",
          "webp": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "54811",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "43366",
          "webp": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "158859",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48467",
          "mp4": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "105624",
          "webp": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "4398",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "9893",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2309750",
          "mp4": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "400",
          "width": "400",
          "size": "37619",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "792326",
          "mp4": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "232",
          "width": "232",
          "mp4_size": "38864",
          "mp4": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "80",
          "width": "80",
          "size": "49620",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "162",
          "width": "162",
          "size": "42756",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "1396171",
          "url": "https://media3.giphy.com/media/JXXyd5GaGHMjA1pj3n/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media2.giphy.com/avatars/dotdave/UWEU18gEPNwb.gif",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/channel/dotdave/",
        "username": "dotdave",
        "display_name": "3D Gif Artist",
        "description": "I'm just a retired old boy who uses ancient CAD software to create these distinctive but weird gifs.",
        "instagram_url": "",
        "website_url": "https://www.3danimatedgifs.com/",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPUpYWHlkNUdhR0hNakExcGozbiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUpYWHlkNUdhR0hNakExcGozbiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUpYWHlkNUdhR0hNakExcGozbiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPUpYWHlkNUdhR0hNakExcGozbiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "nXxOjZrbnbRxS",
      "url": "https://giphy.com/gifs/win-nXxOjZrbnbRxS",
      "slug": "win-nXxOjZrbnbRxS",
      "bitly_gif_url": "http://gph.is/1aR7NWq",
      "bitly_url": "http://gph.is/1aR7NWq",
      "embed_url": "https://giphy.com/embed/nXxOjZrbnbRxS",
      "username": "",
      "source": "http://fuckyeahreactionface.tumblr.com/post/1502545449",
      "title": "Happy Yes It Is GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "fuckyeahreactionface.tumblr.com",
      "source_post_url": "http://fuckyeahreactionface.tumblr.com/post/1502545449",
      "is_sticker": 0,
      "import_datetime": "2013-06-27 14:33:31",
      "trending_datetime": "1970-01-01 00:00:00",
      "images": {
        "original": {
          "height": "270",
          "width": "200",
          "size": "473119",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "1141467",
          "mp4": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "317130",
          "webp": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "31",
          "hash": "fa4e1bc08c3ca0fabfe78e64b10d241f"
        },
        "downsized": {
          "height": "270",
          "width": "200",
          "size": "473119",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "270",
          "width": "200",
          "size": "473119",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "270",
          "width": "200",
          "size": "473119",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "206",
          "width": "152",
          "mp4_size": "33528",
          "mp4": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "270",
          "width": "200",
          "size": "473119",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "148",
          "size": "395760",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "77894",
          "mp4": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "132052",
          "webp": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "148",
          "size": "81114",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "44116",
          "webp": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "74",
          "size": "117992",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "20238",
          "mp4": "https://media0.giphy.com/media/nXxOjZrbnbRxS/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "42004",
          "webp": "https://media0.giphy.com/media/nXxOjZrbnbRxS/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "74",
          "size": "4530",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "148",
          "size": "17439",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "270",
          "width": "200",
          "size": "463155",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "195049",
          "mp4": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "318904",
          "webp": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "270",
          "width": "200",
          "size": "98306",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "83742",
          "webp": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "135",
          "width": "100",
          "size": "185974",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "32134",
          "mp4": "https://media0.giphy.com/media/nXxOjZrbnbRxS/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "64310",
          "webp": "https://media0.giphy.com/media/nXxOjZrbnbRxS/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "135",
          "width": "100",
          "size": "7232",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "270",
          "width": "200",
          "size": "16157",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "4692618",
          "mp4": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "270",
          "width": "200",
          "size": "16524",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "648",
          "width": "480",
          "mp4_size": "1141467",
          "mp4": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "150",
          "width": "111",
          "mp4_size": "17905",
          "mp4": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "82",
          "width": "61",
          "size": "49321",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "128",
          "width": "94",
          "size": "24374",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "648",
          "width": "480",
          "size": "473119",
          "url": "https://media0.giphy.com/media/nXxOjZrbnbRxS/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPW5YeE9qWnJibmJSeFMmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPW5YeE9qWnJibmJSeFMmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPW5YeE9qWnJibmJSeFMmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPW5YeE9qWnJibmJSeFMmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "2A75RyXVzzSI2bx4Gj",
      "url": "https://giphy.com/gifs/hallmarkecards-cute-hallmark-shoebox-2A75RyXVzzSI2bx4Gj",
      "slug": "hallmarkecards-cute-hallmark-shoebox-2A75RyXVzzSI2bx4Gj",
      "bitly_gif_url": "https://gph.is/2yVdSDX",
      "bitly_url": "https://gph.is/2yVdSDX",
      "embed_url": "https://giphy.com/embed/2A75RyXVzzSI2bx4Gj",
      "username": "",
      "source": "https://www.hallmark.com/shop-shoebox/?navMenuSubTitle=By\\%20Card\\%20Collection&navMenu=Main\\%20Menu&navTo=Shoebox&navLocation=Header&navMenuTitle=Cards",
      "title": "Sci Fi Lol GIF by Hallmark Gold Crown",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.hallmark.com",
      "source_post_url": "https://www.hallmark.com/shop-shoebox/?navMenuSubTitle=By\\%20Card\\%20Collection&navMenu=Main\\%20Menu&navTo=Shoebox&navLocation=Header&navMenuTitle=Cards",
      "is_sticker": 0,
      "import_datetime": "2018-11-06 19:21:22",
      "trending_datetime": "2019-10-08 15:15:12",
      "images": {
        "original": {
          "height": "400",
          "width": "400",
          "size": "2284419",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "1264211",
          "mp4": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "1109188",
          "webp": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "30",
          "hash": "4038e7b48a988abf41eb206be6d532ae"
        },
        "downsized": {
          "height": "400",
          "width": "400",
          "size": "1534857",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "400",
          "width": "400",
          "size": "2284419",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "400",
          "width": "400",
          "size": "2284419",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "174",
          "width": "174",
          "mp4_size": "65846",
          "mp4": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "400",
          "width": "400",
          "size": "50059",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "521978",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "155045",
          "mp4": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "321740",
          "webp": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "114102",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "66914",
          "webp": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "168517",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "58343",
          "mp4": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "108142",
          "webp": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "6212",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "17505",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "521978",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "155045",
          "mp4": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "321740",
          "webp": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "114102",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "66914",
          "webp": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "168517",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "48147",
          "mp4": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "108142",
          "webp": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "6212",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "17505",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "5443687",
          "mp4": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "400",
          "width": "400",
          "size": "74763",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "1264211",
          "mp4": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "154",
          "width": "154",
          "mp4_size": "44282",
          "mp4": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "99",
          "width": "99",
          "size": "48400",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "100",
          "width": "100",
          "size": "30854",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "2284419",
          "url": "https://media0.giphy.com/media/2A75RyXVzzSI2bx4Gj/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPTJBNzVSeVhWenpTSTJieDRHaiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTJBNzVSeVhWenpTSTJieDRHaiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTJBNzVSeVhWenpTSTJieDRHaiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTJBNzVSeVhWenpTSTJieDRHaiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "7r4NnMODA5xpjB4QC7",
      "url": "https://giphy.com/gifs/thelonelyisland-the-lonely-island-i-think-you-should-leave-itysl-7r4NnMODA5xpjB4QC7",
      "slug": "thelonelyisland-the-lonely-island-i-think-you-should-leave-itysl-7r4NnMODA5xpjB4QC7",
      "bitly_gif_url": "https://gph.is/g/ae9Mznr",
      "bitly_url": "https://gph.is/g/ae9Mznr",
      "embed_url": "https://giphy.com/embed/7r4NnMODA5xpjB4QC7",
      "username": "thelonelyisland",
      "source": "http://www.thelonelyisland.com/",
      "title": "I Think You Should Leave Tim Robinson GIF by The Lonely Island",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.thelonelyisland.com",
      "source_post_url": "http://www.thelonelyisland.com/",
      "is_sticker": 0,
      "import_datetime": "2021-07-02 01:38:26",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "360",
          "width": "480",
          "size": "900271",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "148588",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "235256",
          "webp": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "33",
          "hash": "9a6385cff24f52f9930288906102e3d0"
        },
        "downsized": {
          "height": "360",
          "width": "480",
          "size": "900271",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "360",
          "width": "480",
          "size": "900271",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "360",
          "width": "480",
          "size": "900271",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "360",
          "width": "480",
          "mp4_size": "148588",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "360",
          "width": "480",
          "size": "900271",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "267",
          "size": "330900",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "64864",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "129784",
          "webp": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "267",
          "size": "86090",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "62078",
          "webp": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "134",
          "size": "120600",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "28191",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "59600",
          "webp": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "134",
          "size": "6314",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "267",
          "size": "16073",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "150",
          "width": "200",
          "size": "209492",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "45833",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "94572",
          "webp": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "150",
          "width": "200",
          "size": "59668",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "42754",
          "webp": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "75",
          "width": "100",
          "size": "79605",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "18845",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "41084",
          "webp": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "75",
          "width": "100",
          "size": "4533",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "150",
          "width": "200",
          "size": "14826",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "936868",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "360",
          "width": "480",
          "size": "49558",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "360",
          "width": "480",
          "mp4_size": "148588",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "288",
          "width": "384",
          "mp4_size": "27985",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "80",
          "width": "107",
          "size": "48317",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "206",
          "width": "274",
          "size": "49008",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "900",
          "width": "1200",
          "mp4_size": "778882",
          "mp4": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "360",
          "width": "480",
          "size": "900271",
          "url": "https://media3.giphy.com/media/7r4NnMODA5xpjB4QC7/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/thelonelyisland/xeKg7YHsR1mV.gif",
        "banner_image": "https://media0.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "banner_url": "https://media0.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "profile_url": "https://giphy.com/thelonelyisland/",
        "username": "thelonelyisland",
        "display_name": "The Lonely Island",
        "description": "",
        "instagram_url": "https://instagram.com/thelonelyisland",
        "website_url": "http://www.thelonelyisland.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPTdyNE5uTU9EQTV4cGpCNFFDNyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTdyNE5uTU9EQTV4cGpCNFFDNyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTdyNE5uTU9EQTV4cGpCNFFDNyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTdyNE5uTU9EQTV4cGpCNFFDNyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "zWZ5mhbDTTrqzcmmhG",
      "url": "https://giphy.com/gifs/theseedoflifefoundation-zWZ5mhbDTTrqzcmmhG",
      "slug": "theseedoflifefoundation-zWZ5mhbDTTrqzcmmhG",
      "bitly_gif_url": "https://gph.is/g/4V8wXXD",
      "bitly_url": "https://gph.is/g/4V8wXXD",
      "embed_url": "https://giphy.com/embed/zWZ5mhbDTTrqzcmmhG",
      "username": "theseedoflifefoundation",
      "source": "https://www.the-sol-foundation.org",
      "title": "Good Night GIF by The Seed of Life Foundation",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.the-sol-foundation.org",
      "source_post_url": "https://www.the-sol-foundation.org",
      "is_sticker": 0,
      "import_datetime": "2021-04-17 00:03:27",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "480",
          "width": "347",
          "size": "2068395",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "778478",
          "mp4": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "481226",
          "webp": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "24",
          "hash": "34e22f6937debcdaf9d6cc81f8f5c6f0"
        },
        "downsized": {
          "height": "480",
          "width": "347",
          "size": "1131672",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "480",
          "width": "347",
          "size": "2068395",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "480",
          "width": "347",
          "size": "2068395",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "352",
          "width": "253",
          "mp4_size": "79682",
          "mp4": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "480",
          "width": "347",
          "size": "46900",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "145",
          "size": "328646",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "60241",
          "mp4": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "107520",
          "webp": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "145",
          "size": "91167",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "57024",
          "webp": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "73",
          "size": "94983",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "17962",
          "mp4": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "34884",
          "webp": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "73",
          "size": "5019",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "145",
          "size": "17643",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "277",
          "width": "200",
          "size": "514650",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "105210",
          "mp4": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "182962",
          "webp": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "277",
          "width": "200",
          "size": "143238",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "101256",
          "webp": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "139",
          "width": "100",
          "size": "180924",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "29665",
          "mp4": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "60364",
          "webp": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "139",
          "width": "100",
          "size": "8496",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "277",
          "width": "200",
          "size": "22031",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "4802602",
          "mp4": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "347",
          "size": "119383",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "662",
          "width": "480",
          "mp4_size": "778478",
          "mp4": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "192",
          "width": "138",
          "mp4_size": "25498",
          "mp4": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "85",
          "width": "61",
          "size": "47354",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "118",
          "width": "86",
          "size": "33174",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "664",
          "width": "480",
          "size": "2068395",
          "url": "https://media3.giphy.com/media/zWZ5mhbDTTrqzcmmhG/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media3.giphy.com/avatars/theseedoflifefoundation/3Q35U7TA7lfl.gif",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/theseedoflifefoundation/",
        "username": "theseedoflifefoundation",
        "display_name": "The Seed of Life Foundation",
        "description": "The Seed of Life Foundation is 501(c)3 tax exempt organization & is committed to Restore Nature | Plant Trees | Honor a Life | Give Hope | Living Legacy with education and engagement.. \r\n\r\nOur Goal is to Conserve Nature and Wildlife.\r\n\r\nCopyright © 2019-2021 The Seed of Life® Foundation.  All rights reserved.",
        "instagram_url": "https://instagram.com/theseedoflifefoundation",
        "website_url": "http://www.the-sol-foundation.org",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPXpXWjVtaGJEVFRycXpjbW1oRyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXpXWjVtaGJEVFRycXpjbW1oRyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXpXWjVtaGJEVFRycXpjbW1oRyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPXpXWjVtaGJEVFRycXpjbW1oRyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "evEgbkGON3VJ2YrGjM",
      "url": "https://giphy.com/gifs/carnivalcruise-carnival-cruise-choose-fun-evEgbkGON3VJ2YrGjM",
      "slug": "carnivalcruise-carnival-cruise-choose-fun-evEgbkGON3VJ2YrGjM",
      "bitly_gif_url": "https://gph.is/g/4bGX3oO",
      "bitly_url": "https://gph.is/g/4bGX3oO",
      "embed_url": "https://giphy.com/embed/evEgbkGON3VJ2YrGjM",
      "username": "carnivalcruise",
      "source": "",
      "title": "Beach Hello GIF by Carnival Cruise Line",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2021-02-17 21:42:12",
      "trending_datetime": "2021-08-11 19:48:17",
      "images": {
        "original": {
          "height": "400",
          "width": "400",
          "size": "3514871",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "584542",
          "mp4": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "945490",
          "webp": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "60",
          "hash": "14d063f7903c8556b6a6cb3bbe051cf2"
        },
        "downsized": {
          "height": "320",
          "width": "320",
          "size": "1925426",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "400",
          "width": "400",
          "size": "3514871",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "400",
          "width": "400",
          "size": "3514871",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "258",
          "width": "258",
          "mp4_size": "80264",
          "mp4": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "320",
          "width": "320",
          "size": "33191",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "965809",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "109268",
          "mp4": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "320920",
          "webp": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "109867",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "72622",
          "webp": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "302865",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "41048",
          "mp4": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "110914",
          "webp": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "6235",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "17999",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "965809",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "109268",
          "mp4": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "320920",
          "webp": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "109867",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "72622",
          "webp": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "302865",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "41048",
          "mp4": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "110914",
          "webp": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "6235",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "17999",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2735562",
          "mp4": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "400",
          "width": "400",
          "size": "82920",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "584542",
          "mp4": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "244",
          "width": "244",
          "mp4_size": "30674",
          "mp4": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "77",
          "width": "77",
          "size": "49505",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "104",
          "width": "104",
          "size": "31508",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "3514871",
          "url": "https://media1.giphy.com/media/evEgbkGON3VJ2YrGjM/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media0.giphy.com/avatars/carnivalcruise/1HRKfGbhLiwx.jpg",
        "banner_image": "https://media0.giphy.com/headers/carnivalcruise/lmV6h6TxPetX.gif",
        "banner_url": "https://media0.giphy.com/headers/carnivalcruise/lmV6h6TxPetX.gif",
        "profile_url": "https://giphy.com/carnivalcruise/",
        "username": "carnivalcruise",
        "display_name": "Carnival Cruise Line",
        "description": "The official Giphy page of Carnival Cruise Line. #ChooseFun",
        "instagram_url": "https://instagram.com/@carnival",
        "website_url": "",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPWV2RWdia0dPTjNWSjJZckdqTSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWV2RWdia0dPTjNWSjJZckdqTSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWV2RWdia0dPTjNWSjJZckdqTSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWV2RWdia0dPTjNWSjJZckdqTSZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "TRLIlmDAsLEbK",
      "url": "https://giphy.com/gifs/midnightcake-happy-birthday-TRLIlmDAsLEbK",
      "slug": "midnightcake-happy-birthday-TRLIlmDAsLEbK",
      "bitly_gif_url": "http://gph.is/2tFyhLa",
      "bitly_url": "http://gph.is/2tFyhLa",
      "embed_url": "https://giphy.com/embed/TRLIlmDAsLEbK",
      "username": "midnightcake",
      "source": "http://www.midnightcake.com",
      "title": "happy birthday cake GIF by midnightcake",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.midnightcake.com",
      "source_post_url": "http://www.midnightcake.com",
      "is_sticker": 0,
      "import_datetime": "2017-07-11 20:31:50",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "480",
          "width": "480",
          "size": "1047646",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "377726",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "375982",
          "webp": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "90",
          "hash": "badb39b9c1b5d745edc674d2e14d37c9"
        },
        "downsized": {
          "height": "480",
          "width": "480",
          "size": "1047646",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "480",
          "width": "480",
          "size": "1047646",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "480",
          "width": "480",
          "size": "1047646",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "348",
          "width": "348",
          "mp4_size": "172852",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "480",
          "width": "480",
          "size": "1047646",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "245709",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "145656",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "183782",
          "webp": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "25160",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "17566",
          "webp": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "101933",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "67362",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "86098",
          "webp": "https://media1.giphy.com/media/TRLIlmDAsLEbK/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "204",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "486",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "245709",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "145656",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "183782",
          "webp": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "25160",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "17566",
          "webp": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "101933",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "46183",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "86098",
          "webp": "https://media1.giphy.com/media/TRLIlmDAsLEbK/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "204",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "486",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "829361",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "480",
          "size": "804",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "377726",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "480",
          "width": "480",
          "mp4_size": "39875",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "480",
          "width": "480",
          "size": "32797",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "480",
          "width": "480",
          "size": "20958",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "720",
          "width": "720",
          "mp4_size": "556665",
          "mp4": "https://media1.giphy.com/media/TRLIlmDAsLEbK/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "1047646",
          "url": "https://media1.giphy.com/media/TRLIlmDAsLEbK/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media2.giphy.com/avatars/midnightcake/NbpENnZACdMp.jpg",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/midnightcake/",
        "username": "midnightcake",
        "display_name": "midnightcake",
        "description": "Deliver cake and flowers at midnight or anytime of the day along with your Feelings & Emotions.",
        "instagram_url": "https://instagram.com/midnightcake",
        "website_url": "http://www.midnightcake.com",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPVRSTElsbURBc0xFYksmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRSTElsbURBc0xFYksmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRSTElsbURBc0xFYksmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRSTElsbURBc0xFYksmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "TelvmEeuvuS0Rmx0uD",
      "url": "https://giphy.com/gifs/agt-nbc-americas-got-talent-live-shows-TelvmEeuvuS0Rmx0uD",
      "slug": "agt-nbc-americas-got-talent-live-shows-TelvmEeuvuS0Rmx0uD",
      "bitly_gif_url": "https://gph.is/g/Z510X1G",
      "bitly_url": "https://gph.is/g/Z510X1G",
      "embed_url": "https://giphy.com/embed/TelvmEeuvuS0Rmx0uD",
      "username": "agt",
      "source": "",
      "title": "Sofia Vergara Dancing GIF by America's Got Talent",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2020-09-11 17:02:57",
      "trending_datetime": "2021-08-11 19:45:13",
      "images": {
        "original": {
          "height": "281",
          "width": "500",
          "size": "1322394",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "234038",
          "mp4": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "401826",
          "webp": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "18",
          "hash": "5ed9435cf04803fa78bafd600d0ec405"
        },
        "downsized": {
          "height": "281",
          "width": "500",
          "size": "1322394",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "281",
          "width": "500",
          "size": "1322394",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "281",
          "width": "500",
          "size": "1322394",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "228",
          "width": "407",
          "mp4_size": "80280",
          "mp4": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "281",
          "width": "500",
          "size": "1322394",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "356",
          "size": "482141",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "120152",
          "mp4": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "181912",
          "webp": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "356",
          "size": "174260",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "95950",
          "webp": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "178",
          "size": "153854",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "44481",
          "mp4": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "75724",
          "webp": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "178",
          "size": "10001",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "356",
          "size": "27034",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "112",
          "width": "200",
          "size": "203017",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "49085",
          "mp4": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "84600",
          "webp": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "112",
          "width": "200",
          "size": "66891",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "36948",
          "webp": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "56",
          "width": "100",
          "size": "58471",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "20474",
          "mp4": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "35924",
          "webp": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "56",
          "width": "100",
          "size": "3941",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "112",
          "width": "200",
          "size": "12939",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1986542",
          "mp4": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "281",
          "width": "500",
          "size": "87165",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "268",
          "width": "480",
          "mp4_size": "234038",
          "mp4": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "114",
          "width": "203",
          "mp4_size": "30880",
          "mp4": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "54",
          "width": "96",
          "size": "49632",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "98",
          "width": "174",
          "size": "39818",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "270",
          "width": "480",
          "size": "1322394",
          "url": "https://media3.giphy.com/media/TelvmEeuvuS0Rmx0uD/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media4.giphy.com/avatars/agt/pj1HFAZXRyBX.jpg",
        "banner_image": "https://media4.giphy.com/headers/agt/Y1NbJ5l2YqfC.jpg",
        "banner_url": "https://media4.giphy.com/headers/agt/Y1NbJ5l2YqfC.jpg",
        "profile_url": "https://giphy.com/agt/",
        "username": "agt",
        "display_name": "America's Got Talent",
        "description": "✨ Life, liberty, and the pursuit of talent. ✨ Don't miss the premiere of AGT June 1 8/7c on NBC!",
        "instagram_url": "https://instagram.com/agt",
        "website_url": "http://www.nbc.com/americas-got-talent",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPVRlbHZtRWV1dnVTMFJteDB1RCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRlbHZtRWV1dnVTMFJteDB1RCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRlbHZtRWV1dnVTMFJteDB1RCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVRlbHZtRWV1dnVTMFJteDB1RCZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "cPI7HWjOjkJeNG9zRw",
      "url": "https://giphy.com/gifs/love-amor-i-u-cPI7HWjOjkJeNG9zRw",
      "slug": "love-amor-i-u-cPI7HWjOjkJeNG9zRw",
      "bitly_gif_url": "https://gph.is/g/ZYoNjQJ",
      "bitly_url": "https://gph.is/g/ZYoNjQJ",
      "embed_url": "https://giphy.com/embed/cPI7HWjOjkJeNG9zRw",
      "username": "raintome",
      "source": "https://www.instagram.com/rain.to.me/",
      "title": "I Love You Miss GIF by RainToMe",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.instagram.com",
      "source_post_url": "https://www.instagram.com/rain.to.me/",
      "is_sticker": 0,
      "import_datetime": "2020-09-02 22:17:44",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "480",
          "width": "480",
          "size": "221635",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "128271",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "184204",
          "webp": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "14",
          "hash": "8aee08f85b393177d028e2b0466c2f66"
        },
        "downsized": {
          "height": "480",
          "width": "480",
          "size": "221635",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "480",
          "width": "480",
          "size": "221635",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "480",
          "width": "480",
          "size": "221635",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "480",
          "width": "480",
          "mp4_size": "126005",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "480",
          "width": "480",
          "size": "221635",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "68350",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "52751",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "75984",
          "webp": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "27752",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "31640",
          "webp": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "31020",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "23551",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "34986",
          "webp": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "2926",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "5525",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "68350",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "52751",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "75984",
          "webp": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "27752",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "31640",
          "webp": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "31020",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "23551",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "34986",
          "webp": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "2926",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "5525",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1328708",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "480",
          "width": "480",
          "size": "24216",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "128271",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "302",
          "width": "302",
          "mp4_size": "49120",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "121",
          "width": "121",
          "size": "49820",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "184",
          "width": "184",
          "size": "49984",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "1080",
          "width": "1080",
          "mp4_size": "295043",
          "mp4": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "221635",
          "url": "https://media2.giphy.com/media/cPI7HWjOjkJeNG9zRw/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media3.giphy.com/avatars/raintome/Hs39aDJCqI48.png",
        "banner_image": "https://media3.giphy.com/headers/raintome/w3CZFHIMEFvG.png",
        "banner_url": "https://media3.giphy.com/headers/raintome/w3CZFHIMEFvG.png",
        "profile_url": "https://giphy.com/raintome/",
        "username": "raintome",
        "display_name": "RainToMe",
        "description": "Concepción based illustrator, artist and vlogger.\r\nContact me: fabiariger@gmail.com\r\nYoutube: https://bit.ly/3dznbfq",
        "instagram_url": "https://instagram.com/rain",
        "website_url": "https://www.instagram.com/rain.to.me",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPWNQSTdIV2pPamtKZU5HOXpSdyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWNQSTdIV2pPamtKZU5HOXpSdyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWNQSTdIV2pPamtKZU5HOXpSdyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWNQSTdIV2pPamtKZU5HOXpSdyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "WJjLyXCVvro2I",
      "url": "https://giphy.com/gifs/WJjLyXCVvro2I",
      "slug": "WJjLyXCVvro2I",
      "bitly_gif_url": "http://gph.is/1K2G46i",
      "bitly_url": "http://gph.is/1K2G46i",
      "embed_url": "https://giphy.com/embed/WJjLyXCVvro2I",
      "username": "",
      "source": "http://www.reddit.com/r/reactiongifs/comments/3kkouc/mrw_im_getting_ready_for_a_party_and_cant_find_my/",
      "title": "Jack Black Reaction GIF",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.reddit.com",
      "source_post_url": "http://www.reddit.com/r/reactiongifs/comments/3kkouc/mrw_im_getting_ready_for_a_party_and_cant_find_my/",
      "is_sticker": 0,
      "import_datetime": "2015-09-11 18:41:56",
      "trending_datetime": "2019-05-11 06:45:01",
      "images": {
        "original": {
          "height": "215",
          "width": "244",
          "size": "4152601",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "2901658",
          "mp4": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "1630658",
          "webp": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "281",
          "hash": "dc1bfe83c4f3d7d24b745593eea73c45"
        },
        "downsized": {
          "height": "215",
          "width": "244",
          "size": "817041",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy-downsized.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized.gif&ct=g"
        },
        "downsized_large": {
          "height": "215",
          "width": "244",
          "size": "4152601",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "215",
          "width": "244",
          "size": "4152601",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "130",
          "width": "148",
          "mp4_size": "88341",
          "mp4": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "215",
          "width": "244",
          "size": "21231",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy-downsized_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "227",
          "size": "4390616",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "450259",
          "mp4": "https://media0.giphy.com/media/WJjLyXCVvro2I/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "1377702",
          "webp": "https://media0.giphy.com/media/WJjLyXCVvro2I/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "227",
          "size": "120043",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "68652",
          "webp": "https://media0.giphy.com/media/WJjLyXCVvro2I/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "114",
          "size": "1418255",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "132233",
          "mp4": "https://media0.giphy.com/media/WJjLyXCVvro2I/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "487806",
          "webp": "https://media0.giphy.com/media/WJjLyXCVvro2I/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "114",
          "size": "6138",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "227",
          "size": "17823",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "176",
          "width": "200",
          "size": "3513603",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "322990",
          "mp4": "https://media0.giphy.com/media/WJjLyXCVvro2I/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "1081404",
          "webp": "https://media0.giphy.com/media/WJjLyXCVvro2I/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "176",
          "width": "200",
          "size": "88548",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "54862",
          "webp": "https://media0.giphy.com/media/WJjLyXCVvro2I/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "88",
          "width": "100",
          "size": "1163318",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "45869",
          "mp4": "https://media0.giphy.com/media/WJjLyXCVvro2I/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "406924",
          "webp": "https://media0.giphy.com/media/WJjLyXCVvro2I/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "88",
          "width": "100",
          "size": "5214",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "176",
          "width": "200",
          "size": "15818",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2609868",
          "mp4": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "215",
          "width": "244",
          "size": "26328",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "422",
          "width": "480",
          "mp4_size": "2901658",
          "mp4": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "214",
          "width": "244",
          "mp4_size": "44949",
          "mp4": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "75",
          "width": "85",
          "size": "48036",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "132",
          "width": "150",
          "size": "42620",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "423",
          "width": "480",
          "size": "4152601",
          "url": "https://media0.giphy.com/media/WJjLyXCVvro2I/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPVdKakx5WENWdnJvMkkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVdKakx5WENWdnJvMkkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVdKakx5WENWdnJvMkkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVdKakx5WENWdnJvMkkmZXZlbnRfdHlwZT1HSUZfVFJFTkRJTkcmY2lkPWI0YWIwODU1Yzh0NXFrcmptbDRwOHI5MjgweGlpeXZjaGNyMGE2aWhuaDJpamVqcCZjdD1naWY&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "Q7ozWVYCR0nyW2rvPW",
      "url": "https://giphy.com/gifs/moodman-lol-spit-take-Q7ozWVYCR0nyW2rvPW",
      "slug": "moodman-lol-spit-take-Q7ozWVYCR0nyW2rvPW",
      "bitly_gif_url": "https://gph.is/g/4b1PXk9",
      "bitly_url": "https://gph.is/g/4b1PXk9",
      "embed_url": "https://giphy.com/embed/Q7ozWVYCR0nyW2rvPW",
      "username": "",
      "source": "",
      "title": "Big Brother Reaction GIF by MOODMAN",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2020-07-23 21:17:14",
      "trending_datetime": "2021-07-01 09:00:07",
      "images": {
        "original": {
          "height": "314",
          "width": "300",
          "size": "1146880",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "169918",
          "mp4": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "233108",
          "webp": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "28",
          "hash": "a3d35aa6644545ddb4f79a8d45ed270a"
        },
        "downsized": {
          "height": "314",
          "width": "300",
          "size": "1146880",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "314",
          "width": "300",
          "size": "1146880",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "314",
          "width": "300",
          "size": "1146880",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "314",
          "width": "300",
          "mp4_size": "169918",
          "mp4": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "314",
          "width": "300",
          "size": "1146880",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "191",
          "size": "381015",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "94264",
          "mp4": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "141858",
          "webp": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "191",
          "size": "87512",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "50978",
          "webp": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "96",
          "size": "129337",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "39298",
          "mp4": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "61496",
          "webp": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "96",
          "size": "5443",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "191",
          "size": "14439",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "209",
          "width": "200",
          "size": "410978",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "102424",
          "mp4": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "151616",
          "webp": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "209",
          "width": "200",
          "size": "96963",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "55056",
          "webp": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "105",
          "width": "100",
          "size": "139297",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "42728",
          "mp4": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "65036",
          "webp": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "105",
          "width": "100",
          "size": "5751",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "209",
          "width": "200",
          "size": "15463",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2573807",
          "mp4": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "314",
          "width": "300",
          "size": "40915",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "314",
          "width": "300",
          "mp4_size": "169918",
          "mp4": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "170",
          "width": "162",
          "mp4_size": "36864",
          "mp4": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "72",
          "width": "69",
          "size": "49468",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "166",
          "width": "158",
          "size": "41484",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "502",
          "width": "480",
          "size": "1146880",
          "url": "https://media4.giphy.com/media/Q7ozWVYCR0nyW2rvPW/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPVE3b3pXVllDUjBueVcycnZQVyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVE3b3pXVllDUjBueVcycnZQVyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVE3b3pXVllDUjBueVcycnZQVyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVE3b3pXVllDUjBueVcycnZQVyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "QXIQXOrhSV3TQegImB",
      "url": "https://giphy.com/gifs/memecandy-QXIQXOrhSV3TQegImB",
      "slug": "memecandy-QXIQXOrhSV3TQegImB",
      "bitly_gif_url": "https://gph.is/g/Zx2VPwP",
      "bitly_url": "https://gph.is/g/Zx2VPwP",
      "embed_url": "https://giphy.com/embed/QXIQXOrhSV3TQegImB",
      "username": "memecandy",
      "source": "",
      "title": "Sweet Dreams GIF by memecandy",
      "rating": "g",
      "content_url": "",
      "source_tld": "",
      "source_post_url": "",
      "is_sticker": 0,
      "import_datetime": "2019-12-11 23:45:43",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "320",
          "width": "240",
          "size": "645296",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "505466",
          "mp4": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "307216",
          "webp": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "24",
          "hash": "1d7e918b002801ddc72f3cd010ca46d8"
        },
        "downsized": {
          "height": "320",
          "width": "240",
          "size": "645296",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "320",
          "width": "240",
          "size": "645296",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "320",
          "width": "240",
          "size": "645296",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "320",
          "width": "240",
          "mp4_size": "133293",
          "mp4": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "320",
          "width": "240",
          "size": "645296",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "150",
          "size": "237070",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "41221",
          "mp4": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "155538",
          "webp": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "150",
          "size": "64822",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "48460",
          "webp": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "75",
          "size": "78984",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "14716",
          "mp4": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "47136",
          "webp": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "75",
          "size": "4295",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "150",
          "size": "15179",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "267",
          "width": "200",
          "size": "389355",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "61144",
          "mp4": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "229538",
          "webp": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "267",
          "width": "200",
          "size": "108355",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "74792",
          "webp": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "134",
          "width": "100",
          "size": "124637",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "23318",
          "mp4": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "75944",
          "webp": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "134",
          "width": "100",
          "size": "6232",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "267",
          "width": "200",
          "size": "16618",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "1385845",
          "mp4": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "320",
          "width": "240",
          "size": "36505",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "640",
          "width": "480",
          "mp4_size": "505466",
          "mp4": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "194",
          "width": "145",
          "mp4_size": "23459",
          "mp4": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "79",
          "width": "59",
          "size": "47305",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "158",
          "width": "118",
          "size": "45530",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "640",
          "width": "480",
          "size": "645296",
          "url": "https://media0.giphy.com/media/QXIQXOrhSV3TQegImB/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media1.giphy.com/avatars/default5.gif",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/memecandy/",
        "username": "memecandy",
        "display_name": "",
        "description": "",
        "instagram_url": "",
        "website_url": "",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPVFYSVFYT3JoU1YzVFFlZ0ltQiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVFYSVFYT3JoU1YzVFFlZ0ltQiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVFYSVFYT3JoU1YzVFFlZ0ltQiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVFYSVFYT3JoU1YzVFFlZ0ltQiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "6ryyeYE2A0UOPvgVUW",
      "url": "https://giphy.com/gifs/thelonelyisland-i-think-you-should-leave-tim-robinson-itysl-6ryyeYE2A0UOPvgVUW",
      "slug": "thelonelyisland-i-think-you-should-leave-tim-robinson-itysl-6ryyeYE2A0UOPvgVUW",
      "bitly_gif_url": "https://gph.is/g/Zy07Gev",
      "bitly_url": "https://gph.is/g/Zy07Gev",
      "embed_url": "https://giphy.com/embed/6ryyeYE2A0UOPvgVUW",
      "username": "thelonelyisland",
      "source": "http://www.thelonelyisland.com",
      "title": "Season 2 No GIF by The Lonely Island",
      "rating": "g",
      "content_url": "",
      "source_tld": "www.thelonelyisland.com",
      "source_post_url": "http://www.thelonelyisland.com",
      "is_sticker": 0,
      "import_datetime": "2021-07-04 19:44:06",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "360",
          "width": "480",
          "size": "604705",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "111188",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "118482",
          "webp": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "11",
          "hash": "fe5690f0e9aae7333e495dee7c8121cf"
        },
        "downsized": {
          "height": "360",
          "width": "480",
          "size": "604705",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "360",
          "width": "480",
          "size": "604705",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "360",
          "width": "480",
          "size": "604705",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "360",
          "width": "480",
          "mp4_size": "111188",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "360",
          "width": "480",
          "size": "604705",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "267",
          "size": "178356",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "45835",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "60660",
          "webp": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "267",
          "size": "116478",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "59442",
          "webp": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "134",
          "size": "63010",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "19395",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "28148",
          "webp": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "134",
          "size": "5775",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "267",
          "size": "15020",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "150",
          "width": "200",
          "size": "142831",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "31976",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "44596",
          "webp": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "150",
          "width": "200",
          "size": "79676",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "39204",
          "webp": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "75",
          "width": "100",
          "size": "42295",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "12829",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "19930",
          "webp": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "75",
          "width": "100",
          "size": "4158",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "150",
          "width": "200",
          "size": "12909",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "2137815",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "360",
          "width": "480",
          "size": "54667",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "360",
          "width": "480",
          "mp4_size": "111188",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "240",
          "width": "320",
          "mp4_size": "30158",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "71",
          "width": "95",
          "size": "48190",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "196",
          "width": "262",
          "size": "44088",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "hd": {
          "height": "900",
          "width": "1200",
          "mp4_size": "484641",
          "mp4": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/giphy-hd.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-hd.mp4&ct=g"
        },
        "480w_still": {
          "height": "360",
          "width": "480",
          "size": "604705",
          "url": "https://media1.giphy.com/media/6ryyeYE2A0UOPvgVUW/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media1.giphy.com/avatars/thelonelyisland/xeKg7YHsR1mV.gif",
        "banner_image": "https://media1.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "banner_url": "https://media1.giphy.com/headers/thelonelyisland/hYqqtAS9XKMh.jpeg",
        "profile_url": "https://giphy.com/thelonelyisland/",
        "username": "thelonelyisland",
        "display_name": "The Lonely Island",
        "description": "",
        "instagram_url": "https://instagram.com/thelonelyisland",
        "website_url": "http://www.thelonelyisland.com",
        "is_verified": true
      },
      "analytics_response_payload": "e=Z2lmX2lkPTZyeXllWUUyQTBVT1B2Z1ZVVyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTZyeXllWUUyQTBVT1B2Z1ZVVyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTZyeXllWUUyQTBVT1B2Z1ZVVyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPTZyeXllWUUyQTBVT1B2Z1ZVVyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "iTqI8LNCoz7SSnIhe3",
      "url": "https://giphy.com/gifs/kikitech-iTqI8LNCoz7SSnIhe3",
      "slug": "kikitech-iTqI8LNCoz7SSnIhe3",
      "bitly_gif_url": "https://gph.is/g/4DeGRgn",
      "bitly_url": "https://gph.is/g/4DeGRgn",
      "embed_url": "https://giphy.com/embed/iTqI8LNCoz7SSnIhe3",
      "username": "kikitech",
      "source": "https://play.google.com/store/apps/details?id=com.kiki.prod",
      "title": "Good Night Cat GIF by Kiki",
      "rating": "g",
      "content_url": "https://apps.apple.com/id/app/kiki-pte-ltd/id1517974629",
      "source_tld": "play.google.com",
      "source_post_url": "https://play.google.com/store/apps/details?id=com.kiki.prod",
      "is_sticker": 0,
      "import_datetime": "2020-12-04 05:11:52",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "240",
          "width": "240",
          "size": "43247",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "60031",
          "mp4": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "39504",
          "webp": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "9",
          "hash": "50265c99e59dd4077bd3455c321a3a39"
        },
        "downsized": {
          "height": "240",
          "width": "240",
          "size": "43247",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "240",
          "width": "240",
          "size": "43247",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "240",
          "width": "240",
          "size": "43247",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "240",
          "width": "240",
          "mp4_size": "30681",
          "mp4": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "240",
          "width": "240",
          "size": "43247",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "200",
          "size": "33894",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "24725",
          "mp4": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "29992",
          "webp": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "200",
          "size": "31700",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "28862",
          "webp": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "100",
          "size": "15159",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "12402",
          "mp4": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "14342",
          "webp": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "100",
          "size": "3721",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "200",
          "size": "8697",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "200",
          "width": "200",
          "size": "33894",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "24725",
          "mp4": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "29992",
          "webp": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "200",
          "width": "200",
          "size": "31700",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "28862",
          "webp": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "100",
          "width": "100",
          "size": "15159",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "12402",
          "mp4": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "14342",
          "webp": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "100",
          "width": "100",
          "size": "3721",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "200",
          "width": "200",
          "size": "8697",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "700162",
          "mp4": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "240",
          "width": "240",
          "size": "13767",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "480",
          "width": "480",
          "mp4_size": "60031",
          "mp4": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "240",
          "width": "240",
          "mp4_size": "30681",
          "mp4": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "240",
          "width": "240",
          "size": "31454",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "240",
          "width": "240",
          "size": "39504",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "480",
          "width": "480",
          "size": "43247",
          "url": "https://media0.giphy.com/media/iTqI8LNCoz7SSnIhe3/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "user": {
        "avatar_url": "https://media1.giphy.com/avatars/kikitech/IdDuvKN3zEer.png",
        "banner_image": "",
        "banner_url": "",
        "profile_url": "https://giphy.com/kikitech/",
        "username": "kikitech",
        "display_name": "Kiki",
        "description": "KiKi is a short-video platform dedicated to lifestyle. KiKi is a beauty, fashion, travel, hobby and lifestyle community which feature reviews, information, and tutorials. All content is user generated and peer-reviewed. The products discussed can be purchased in-app for a safe and hassle-free shopping experience. Use our built-in powerful video shooting and easy editing software to make your content professional.",
        "instagram_url": "https://instagram.com/kiki.id",
        "website_url": "http://kiki.id",
        "is_verified": false
      },
      "analytics_response_payload": "e=Z2lmX2lkPWlUcUk4TE5Db3o3U1NuSWhlMyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWlUcUk4TE5Db3o3U1NuSWhlMyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWlUcUk4TE5Db3o3U1NuSWhlMyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPWlUcUk4TE5Db3o3U1NuSWhlMyZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    },
    {
      "type": "gif",
      "id": "Pnmy6Jn6vlded4aDpZ",
      "url": "https://giphy.com/gifs/moodman-loaf-happy-birthday-weird-Pnmy6Jn6vlded4aDpZ",
      "slug": "moodman-loaf-happy-birthday-weird-Pnmy6Jn6vlded4aDpZ",
      "bitly_gif_url": "https://gph.is/g/4VV7nV6",
      "bitly_url": "https://gph.is/g/4VV7nV6",
      "embed_url": "https://giphy.com/embed/Pnmy6Jn6vlded4aDpZ",
      "username": "",
      "source": "https://media.giphy.com/media/3oFzm0F8nf3BRILjX2/giphy.gif",
      "title": "Happy Birthday Bread GIF by MOODMAN",
      "rating": "g",
      "content_url": "",
      "source_tld": "media.giphy.com",
      "source_post_url": "https://media.giphy.com/media/3oFzm0F8nf3BRILjX2/giphy.gif",
      "is_sticker": 0,
      "import_datetime": "2020-02-24 20:14:01",
      "trending_datetime": "0000-00-00 00:00:00",
      "images": {
        "original": {
          "height": "360",
          "width": "480",
          "size": "1120348",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g",
          "mp4_size": "254555",
          "mp4": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g",
          "webp_size": "425690",
          "webp": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.webp&ct=g",
          "frames": "15",
          "hash": "9275282511c12bcbfe8f9a5d96a9d2e8"
        },
        "downsized": {
          "height": "360",
          "width": "480",
          "size": "1120348",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_large": {
          "height": "360",
          "width": "480",
          "size": "1120348",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_medium": {
          "height": "360",
          "width": "480",
          "size": "1120348",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.gif&ct=g"
        },
        "downsized_small": {
          "height": "318",
          "width": "424",
          "mp4_size": "50497",
          "mp4": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy-downsized-small.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-downsized-small.mp4&ct=g"
        },
        "downsized_still": {
          "height": "360",
          "width": "480",
          "size": "1120348",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "fixed_height": {
          "height": "200",
          "width": "267",
          "size": "297870",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.gif&ct=g",
          "mp4_size": "42233",
          "mp4": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.mp4&ct=g",
          "webp_size": "177626",
          "webp": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200.webp&ct=g"
        },
        "fixed_height_downsampled": {
          "height": "200",
          "width": "267",
          "size": "155295",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.gif&ct=g",
          "webp_size": "98574",
          "webp": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_d.webp&ct=g"
        },
        "fixed_height_small": {
          "height": "100",
          "width": "134",
          "size": "96421",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/100.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.gif&ct=g",
          "mp4_size": "14987",
          "mp4": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/100.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.mp4&ct=g",
          "webp_size": "70802",
          "webp": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/100.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100.webp&ct=g"
        },
        "fixed_height_small_still": {
          "height": "100",
          "width": "134",
          "size": "9335",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/100_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100_s.gif&ct=g"
        },
        "fixed_height_still": {
          "height": "200",
          "width": "267",
          "size": "24740",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200_s.gif&ct=g"
        },
        "fixed_width": {
          "height": "150",
          "width": "200",
          "size": "190429",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.gif&ct=g",
          "mp4_size": "26208",
          "mp4": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.mp4&ct=g",
          "webp_size": "123294",
          "webp": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w.webp&ct=g"
        },
        "fixed_width_downsampled": {
          "height": "150",
          "width": "200",
          "size": "90240",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200w_d.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.gif&ct=g",
          "webp_size": "63128",
          "webp": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200w_d.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_d.webp&ct=g"
        },
        "fixed_width_small": {
          "height": "75",
          "width": "100",
          "size": "56347",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/100w.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.gif&ct=g",
          "mp4_size": "9493",
          "mp4": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/100w.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.mp4&ct=g",
          "webp_size": "44840",
          "webp": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/100w.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w.webp&ct=g"
        },
        "fixed_width_small_still": {
          "height": "75",
          "width": "100",
          "size": "5709",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/100w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=100w_s.gif&ct=g"
        },
        "fixed_width_still": {
          "height": "150",
          "width": "200",
          "size": "15978",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/200w_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=200w_s.gif&ct=g"
        },
        "looping": {
          "mp4_size": "3506993",
          "mp4": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy-loop.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-loop.mp4&ct=g"
        },
        "original_still": {
          "height": "360",
          "width": "480",
          "size": "90271",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy_s.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy_s.gif&ct=g"
        },
        "original_mp4": {
          "height": "360",
          "width": "480",
          "mp4_size": "254555",
          "mp4": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy.mp4&ct=g"
        },
        "preview": {
          "height": "158",
          "width": "210",
          "mp4_size": "16802",
          "mp4": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy-preview.mp4?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.mp4&ct=g"
        },
        "preview_gif": {
          "height": "75",
          "width": "100",
          "size": "48565",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy-preview.gif?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.gif&ct=g"
        },
        "preview_webp": {
          "height": "88",
          "width": "118",
          "size": "39376",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/giphy-preview.webp?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=giphy-preview.webp&ct=g"
        },
        "480w_still": {
          "height": "360",
          "width": "480",
          "size": "1120348",
          "url": "https://media1.giphy.com/media/Pnmy6Jn6vlded4aDpZ/480w_s.jpg?cid=b4ab0855c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp&rid=480w_s.jpg&ct=g"
        }
      },
      "analytics_response_payload": "e=Z2lmX2lkPVBubXk2Sm42dmxkZWQ0YURwWiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg",
      "analytics": {
        "onload": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVBubXk2Sm42dmxkZWQ0YURwWiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SEEN"
        },
        "onclick": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVBubXk2Sm42dmxkZWQ0YURwWiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=CLICK"
        },
        "onsent": {
          "url": "https://giphy-analytics.giphy.com/v2/pingback_simple?analytics_response_payload=e%3DZ2lmX2lkPVBubXk2Sm42dmxkZWQ0YURwWiZldmVudF90eXBlPUdJRl9UUkVORElORyZjaWQ9YjRhYjA4NTVjOHQ1cWtyam1sNHA4cjkyODB4aWl5dmNoY3IwYTZpaG5oMmlqZWpwJmN0PWdpZg&action_type=SENT"
        }
      }
    }
  ],
  "pagination": {
    "total_count": 9341,
    "count": 50,
    "offset": 0
  },
  "meta": {
    "status": 200,
    "msg": "OK",
    "response_id": "c8t5qkrjml4p8r9280xiiyvchcr0a6ihnh2ijejp"
  }
}